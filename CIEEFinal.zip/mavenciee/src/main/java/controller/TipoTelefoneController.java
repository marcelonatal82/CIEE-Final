package controller;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.List;

import javax.swing.JOptionPane;

import model.TipoTelefone;
import repositorio.TipoTelefoneRepositorio;

public class TipoTelefoneController implements Serializable{

	TipoTelefoneRepositorio repositorio = new TipoTelefoneRepositorio();
	
	public boolean salvar(TipoTelefone modelo) {
		if (modelo.getTipo().isEmpty()==false) {
			System.out.println(modelo.getTipo());
			System.out.println("Pode salvar!!!");
			return repositorio.salvar(modelo);
		}else {
			JOptionPane.showMessageDialog(null,
					"Existem dados obrigatórios que não foram preenchidos",
			        "Impossível continuar",
			        JOptionPane.ERROR_MESSAGE);
			return false;
		}
	}

	public boolean alterar(TipoTelefone modelo) {
					
		if (modelo.getTipo().isEmpty()==false) {
				System.out.println(modelo.getTipo());
				System.out.println("Pode salvar!!!");
				return repositorio.alterar(modelo);
			}else {
				JOptionPane.showMessageDialog(null,
						"Existem dados obrigatórios que não foram preenchidos",
				        "Impossível continuar",
				        JOptionPane.ERROR_MESSAGE);
				return false;
			}
	}
	public boolean excluir(TipoTelefone modelo){
		if (modelo.getTipo().isEmpty() == false) {
			System.out.println(modelo.getTipo());
			System.out.println("Pode Excluir!!!");
			return repositorio.excluir(modelo);
		} else {
			JOptionPane.showMessageDialog(null, "Existem dados obrigatórios que não foram preenchidos",
					"Impossível continuar", JOptionPane.ERROR_MESSAGE);
			return false;
		}
	}

	public boolean buscar(TipoTelefone modelo) {
		// TODO Auto-generated method stub
		return false;
	}

	public TipoTelefone buscar(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<TipoTelefone> buscarTodos() {
		// TODO Auto-generated method stub
		return null;
	}

	public LocalDate Listar() {
		// TODO Auto-generated method stub
		return null;
	}
}
