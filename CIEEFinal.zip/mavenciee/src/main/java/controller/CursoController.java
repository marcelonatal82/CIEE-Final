package controller;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.List;

import javax.swing.JOptionPane;


import model.Curso;
import repositorio.CursoRepositorio;
import controller.IControllerCurso;

public class CursoController implements Serializable{

	CursoRepositorio repositorio = new CursoRepositorio();
	
	public boolean salvar(Curso modelo) {
		if (modelo.getNome_curso().isEmpty()==false) {
			System.out.println(modelo.getNome_curso());
			System.out.println("Pode salvar!!!");
			return repositorio.salvar(modelo);
		}else {
			JOptionPane.showMessageDialog(null,
					"Existem dados obrigatórios que não foram preenchidos",
			        "Impossível continuar",
			        JOptionPane.ERROR_MESSAGE);
			return false;
		}
	}

	public boolean alterar(Curso modelo) {
					
		if (modelo.getNome_curso().isEmpty()==false) {
				System.out.println(modelo.getNome_curso());
				System.out.println("Pode salvar!!!");
				return repositorio.alterar(modelo);
			}else {
				JOptionPane.showMessageDialog(null,
						"Existem dados obrigatórios que não foram preenchidos",
				        "Impossível continuar",
				        JOptionPane.ERROR_MESSAGE);
				return false;
			}
	}
	public boolean excluir(Curso modelo){
		if (modelo.getNome_curso().isEmpty() == false) {
			System.out.println(modelo.getNome_curso());
			System.out.println("Pode Excluir!!!");
			return repositorio.excluir(modelo);
		} else {
			JOptionPane.showMessageDialog(null, "Existem dados obrigatórios que não foram preenchidos",
					"Impossível continuar", JOptionPane.ERROR_MESSAGE);
			return false;
		}
	}

	public boolean buscar(Curso modelo) {
		// TODO Auto-generated method stub
		return false;
	}

	public Curso buscar(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<Curso> buscarTodos() {
		// TODO Auto-generated method stub
		return null;
	}


	public LocalDate Listar() {
		// TODO Auto-generated method stub
		return null;
	}
}
