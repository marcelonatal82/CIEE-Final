package controller;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.List;

import javax.swing.JOptionPane;


import model.Servidor;
import repositorio.ServidorRepositorio;
import controller.IController;

public class ServidorController implements Serializable{

	ServidorRepositorio repositorio = new ServidorRepositorio();
	
	public boolean salvar(Servidor modelo) {
		if (modelo.getNome().isEmpty()==false) {
			System.out.println(modelo.getNome());
			System.out.println("Pode salvar!!!");
			return repositorio.salvar(modelo);
		}else {
			JOptionPane.showMessageDialog(null,
					"Existem dados obrigatórios que não foram preenchidos",
			        "Impossível continuar",
			        JOptionPane.ERROR_MESSAGE);
			return false;
		}
	}

	public boolean alterar(Servidor modelo) {
					
		if (modelo.getNome().isEmpty()==false) {
				System.out.println(modelo.getNome());
				System.out.println("Pode salvar!!!");
				return repositorio.alterar(modelo);
			}else {
				JOptionPane.showMessageDialog(null,
						"Existem dados obrigatórios que não foram preenchidos",
				        "Impossível continuar",
				        JOptionPane.ERROR_MESSAGE);
				return false;
			}
	}
	public boolean excluir(Servidor modelo){
		if (modelo.getNome().isEmpty() == false) {
			System.out.println(modelo.getNome());
			System.out.println("Pode Excluir!!!");
			return repositorio.excluir(modelo);
		} else {
			JOptionPane.showMessageDialog(null, "Existem dados obrigatórios que não foram preenchidos",
					"Impossível continuar", JOptionPane.ERROR_MESSAGE);
			return false;
		}
	}

	public boolean buscar(Servidor modelo) {
		// TODO Auto-generated method stub
		return false;
	}

	public Servidor buscar(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<Servidor> buscarTodos() {
		// TODO Auto-generated method stub
		return null;
	}


	public LocalDate Listar() {
		// TODO Auto-generated method stub
		return null;
	}
}
