package controller;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.List;

import javax.swing.JOptionPane;


import model.Cidade;
import repositorio.CidadeRepositorio;
import controller.IController;

public class CidadeController implements Serializable{

	CidadeRepositorio repositorio = new CidadeRepositorio();
	
	public boolean salvar(Cidade modelo) {
		if (modelo.getCidade().isEmpty()==false) {
			System.out.println(modelo.getCidade());
			System.out.println("Pode salvar!!!");
			return repositorio.salvar(modelo);
		}else {
			JOptionPane.showMessageDialog(null,
					"Existem dados obrigatórios que não foram preenchidos",
			        "Impossível continuar",
			        JOptionPane.ERROR_MESSAGE);
			return false;
		}
	}

	public boolean alterar(Cidade modelo) {
					
		if (modelo.getCidade().isEmpty()==false) {
				System.out.println(modelo.getCidade());
				System.out.println("Pode salvar!!!");
				return repositorio.alterar(modelo);
			}else {
				JOptionPane.showMessageDialog(null,
						"Existem dados obrigatórios que não foram preenchidos",
				        "Impossível continuar",
				        JOptionPane.ERROR_MESSAGE);
				return false;
			}
	}
	public boolean excluir(Cidade modelo){
		if (modelo.getCidade().isEmpty() == false) {
			System.out.println(modelo.getCidade());
			System.out.println("Pode Excluir!!!");
			return repositorio.excluir(modelo);
		} else {
			JOptionPane.showMessageDialog(null, "Existem dados obrigatórios que não foram preenchidos",
					"Impossível continuar", JOptionPane.ERROR_MESSAGE);
			return false;
		}
	}

	public boolean buscar(Cidade modelo) {
		// TODO Auto-generated method stub
		return false;
	}

	public Cidade buscar(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<Cidade> buscarTodos() {
		// TODO Auto-generated method stub
		return null;
	}


	public LocalDate Listar() {
		// TODO Auto-generated method stub
		return null;
	}
}
