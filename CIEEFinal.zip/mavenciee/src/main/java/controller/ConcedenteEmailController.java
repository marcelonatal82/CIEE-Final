package controller;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.List;

import javax.swing.JOptionPane;

import model.ConcedenteEmail;
import repositorio.ConcedenteEmailRepositorio;

public class ConcedenteEmailController implements Serializable{

	ConcedenteEmailRepositorio repositorio = new ConcedenteEmailRepositorio();
	
	public boolean salvar(ConcedenteEmail modelo) {
		if (modelo.getEmail().isEmpty()==false) {
			System.out.println(modelo.getEmail());
			System.out.println("Pode salvar!!!");
			return repositorio.salvar(modelo);
		}else {
			JOptionPane.showMessageDialog(null,
					"Existem dados obrigatórios que não foram preenchidos",
			        "Impossível continuar",
			        JOptionPane.ERROR_MESSAGE);
			return false;
		}
	}

	public boolean alterar(ConcedenteEmail modelo) {
					
		if (modelo.getEmail().isEmpty()==false) {
				System.out.println(modelo.getEmail());
				System.out.println("Pode salvar!!!");
				return repositorio.alterar(modelo);
			}else {
				JOptionPane.showMessageDialog(null,
						"Existem dados obrigatórios que não foram preenchidos",
				        "Impossível continuar",
				        JOptionPane.ERROR_MESSAGE);
				return false;
			}
	}
	public boolean excluir(ConcedenteEmail modelo){
		if (modelo.getEmail().isEmpty() == false) {
			System.out.println(modelo.getEmail());
			System.out.println("Pode Excluir!!!");
			return repositorio.excluir(modelo);
		} else {
			JOptionPane.showMessageDialog(null, "Existem dados obrigatórios que não foram preenchidos",
					"Impossível continuar", JOptionPane.ERROR_MESSAGE);
			return false;
		}
	}

	public boolean buscar(ConcedenteEmail modelo) {
		// TODO Auto-generated method stub
		return false;
	}

	public ConcedenteEmail buscar(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<ConcedenteEmail> buscarTodos() {
		// TODO Auto-generated method stub
		return null;
	}


}
