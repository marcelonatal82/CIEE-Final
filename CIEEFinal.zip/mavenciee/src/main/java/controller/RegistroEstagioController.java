package controller;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.List;

import javax.swing.JOptionPane;

import model.RegistroEstagio;
import repositorio.RegistroEstagioRepositorio;

public class RegistroEstagioController implements Serializable{

	RegistroEstagioRepositorio repositorio = new RegistroEstagioRepositorio();
	
	public boolean salvar(RegistroEstagio modelo) {
		if (modelo.getObservacao().isEmpty()==false) {
			System.out.println(modelo.getObservacao());
			System.out.println("Pode salvar!!!");
			return repositorio.salvar(modelo);
		}else {
			JOptionPane.showMessageDialog(null,
					"Existem dados obrigatórios que não foram preenchidos",
			        "Impossível continuar",
			        JOptionPane.ERROR_MESSAGE);
			return false;
		}
	}

	public boolean alterar(RegistroEstagio modelo) {
					
		if (modelo.getObservacao().isEmpty()==false) {
				System.out.println(modelo.getObservacao());
				System.out.println("Pode salvar!!!");
				return repositorio.alterar(modelo);
			}else {
				JOptionPane.showMessageDialog(null,
						"Existem dados obrigatórios que não foram preenchidos",
				        "Impossível continuar",
				        JOptionPane.ERROR_MESSAGE);
				return false;
			}
	}
	public boolean excluir(RegistroEstagio modelo){
		if (modelo.getObservacao().isEmpty() == false) {
			System.out.println(modelo.getObservacao());
			System.out.println("Pode Excluir!!!");
			return repositorio.excluir(modelo);
		} else {
			JOptionPane.showMessageDialog(null, "Existem dados obrigatórios que não foram preenchidos",
					"Impossível continuar", JOptionPane.ERROR_MESSAGE);
			return false;
		}
	}

	public boolean buscar(RegistroEstagio modelo) {
		// TODO Auto-generated method stub
		return false;
	}

	public RegistroEstagio buscar(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<RegistroEstagio> buscarTodos() {
		// TODO Auto-generated method stub
		return null;
	}

	public LocalDate Listar() {
		// TODO Auto-generated method stub
		return null;
	}
}
