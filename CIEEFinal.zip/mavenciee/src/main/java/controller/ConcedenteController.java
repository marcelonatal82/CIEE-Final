package controller;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.List;

import javax.swing.JOptionPane;

import model.Concedente;
import repositorio.ConcedenteRepositorio;

public class ConcedenteController implements Serializable{

	ConcedenteRepositorio repositorio = new ConcedenteRepositorio();
	
	public boolean salvar(Concedente modelo) {
		if (modelo.getNome_fantasia().isEmpty()==false) {
			System.out.println(modelo.getNome_fantasia());
			System.out.println("Pode salvar!!!");
			return repositorio.salvar(modelo);
		}else {
			JOptionPane.showMessageDialog(null,
					"Existem dados obrigatórios que não foram preenchidos",
			        "Impossível continuar",
			        JOptionPane.ERROR_MESSAGE);
			return false;
		}
	}

	public boolean alterar(Concedente modelo) {
					
		if (modelo.getNome_fantasia().isEmpty()==false) {
				System.out.println(modelo.getNome_fantasia());
				System.out.println("Pode salvar!!!");
				return repositorio.alterar(modelo);
			}else {
				JOptionPane.showMessageDialog(null,
						"Existem dados obrigatórios que não foram preenchidos",
				        "Impossível continuar",
				        JOptionPane.ERROR_MESSAGE);
				return false;
			}
	}
	public boolean excluir(Concedente modelo){
		if (modelo.getNome_fantasia().isEmpty() == false) {
			System.out.println(modelo.getNome_fantasia());
			System.out.println("Pode Excluir!!!");
			return repositorio.excluir(modelo);
		} else {
			JOptionPane.showMessageDialog(null, "Existem dados obrigatórios que não foram preenchidos",
					"Impossível continuar", JOptionPane.ERROR_MESSAGE);
			return false;
		}
	}

	public boolean buscar(Concedente modelo) {
		// TODO Auto-generated method stub
		return false;
	}

	public Concedente buscar(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<Concedente> buscarTodos() {
		// TODO Auto-generated method stub
		return null;
	}

	public LocalDate Listar() {
		// TODO Auto-generated method stub
		return null;
	}
}
