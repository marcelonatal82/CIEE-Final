package controller;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.List;

import javax.swing.JOptionPane;

import model.ConcedenteTelefone;
import repositorio.ConcedenteTelefoneRepositorio;

public class ConcedenteTelefoneController implements Serializable{

	ConcedenteTelefoneRepositorio repositorio = new ConcedenteTelefoneRepositorio();
	
	public boolean salvar(ConcedenteTelefone modelo) {
		if (modelo.getTelefone().isEmpty()==false) {
			System.out.println(modelo.getTelefone());
			System.out.println("Pode salvar!!!");
			return repositorio.salvar(modelo);
		}else {
			JOptionPane.showMessageDialog(null,
					"Existem dados obrigatórios que não foram preenchidos",
			        "Impossível continuar",
			        JOptionPane.ERROR_MESSAGE);
			return false;
		}
	}

	public boolean alterar(ConcedenteTelefone modelo) {
					
		if (modelo.getTelefone().isEmpty()==false) {
				System.out.println(modelo.getTelefone());
				System.out.println("Pode salvar!!!");
				return repositorio.alterar(modelo);
			}else {
				JOptionPane.showMessageDialog(null,
						"Existem dados obrigatórios que não foram preenchidos",
				        "Impossível continuar",
				        JOptionPane.ERROR_MESSAGE);
				return false;
			}
	}
	public boolean excluir(ConcedenteTelefone modelo){
		if (modelo.getTelefone().isEmpty() == false) {
			System.out.println(modelo.getTelefone());
			System.out.println("Pode Excluir!!!");
			return repositorio.excluir(modelo);
		} else {
			JOptionPane.showMessageDialog(null, "Existem dados obrigatórios que não foram preenchidos",
					"Impossível continuar", JOptionPane.ERROR_MESSAGE);
			return false;
		}
	}

	public boolean buscar(ConcedenteTelefone modelo) {
		// TODO Auto-generated method stub
		return false;
	}

	public ConcedenteTelefone buscar(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<ConcedenteTelefone> buscarTodos() {
		// TODO Auto-generated method stub
		return null;
	}

	public LocalDate Listar() {
		// TODO Auto-generated method stub
		return null;
	}
}
