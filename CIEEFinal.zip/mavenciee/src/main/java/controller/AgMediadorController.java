package controller;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.List;

import javax.swing.JOptionPane;


import model.AgenteMediador;
import repositorio.AgMediadorRepositorio;
import controller.IController;

public class AgMediadorController implements Serializable{

	AgMediadorRepositorio repositorio = new AgMediadorRepositorio();
	
	public boolean salvar(AgenteMediador modelo) {
		if (modelo.getNome().isEmpty()==false) {
			System.out.println(modelo.getNome());
			System.out.println("Pode salvar!!!");
			return repositorio.salvar(modelo);
		}else {
			JOptionPane.showMessageDialog(null,
					"Existem dados obrigatórios que não foram preenchidos",
			        "Impossível continuar",
			        JOptionPane.ERROR_MESSAGE);
			return false;
		}
	}

	public boolean alterar(AgenteMediador modelo) {
					
		if (modelo.getNome().isEmpty()==false) {
				System.out.println(modelo.getNome());
				System.out.println("Pode salvar!!!");
				return repositorio.alterar(modelo);
			}else {
				JOptionPane.showMessageDialog(null,
						"Existem dados obrigatórios que não foram preenchidos",
				        "Impossível continuar",
				        JOptionPane.ERROR_MESSAGE);
				return false;
			}
	}
	public boolean excluir(AgenteMediador modelo){
		if (modelo.getNome().isEmpty() == false) {
			System.out.println(modelo.getNome());
			System.out.println("Pode Excluir!!!");
			return repositorio.excluir(modelo);
		} else {
			JOptionPane.showMessageDialog(null, "Existem dados obrigatórios que não foram preenchidos",
					"Impossível continuar", JOptionPane.ERROR_MESSAGE);
			return false;
		}
	}

	public boolean buscar(AgenteMediador modelo) {
		// TODO Auto-generated method stub
		return false;
	}

	public AgenteMediador buscar(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<AgenteMediador> buscarTodos() {
		// TODO Auto-generated method stub
		return null;
	}


	public LocalDate Listar() {
		// TODO Auto-generated method stub
		return null;
	}
}
