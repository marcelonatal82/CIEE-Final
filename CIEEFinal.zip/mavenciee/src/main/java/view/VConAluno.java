package view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import controller.AlunoController;
import model.Aluno;
import repositorio.DBConnection;

import javax.swing.ListSelectionModel;
import java.awt.Font;
import javax.swing.border.TitledBorder;
import javax.swing.border.EtchedBorder;
import java.awt.Color;
import javax.swing.JScrollPane;
import javax.swing.BoxLayout;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;

public class VConAluno extends JFrame {

	private JPanel contentPane;
	private JTable tbAluno;
	private JButton btnAlterar;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					VConAluno frame = new VConAluno();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public VConAluno() {
		setTitle("LISTAR ALUNOS ESTAGIO");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 578, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		JButton btnListar = new JButton("Listar");
		btnListar.setBounds(10, 43, 73, 23);
		btnListar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) { 
				System.out.println("Aqui!");
					Connection connection;
					try {
						connection = DBConnection.getInstance().getConnection();
						System.out.println(connection.getCatalog());
						String sql = "select * from aluno";
						PreparedStatement preparedStatement1 = connection.prepareStatement(sql);
									
						ResultSet rs = preparedStatement1.executeQuery();

						DefaultTableModel modelo = (DefaultTableModel) tbAluno.getModel();

						modelo.setNumRows(0);

						while (rs.next()) {
				
							modelo.addRow(new Object[]{rs.getString("id"), rs.getString("nome"), rs.getString("numero_matricula"),rs.getString("email"),rs.getDate("data_cadastro")});

						}
			
						rs.close();
						connection.close();
				
	
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}				
						

				}
				
		});
		contentPane.setLayout(null);
		contentPane.add(btnListar);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(93, 5, 459, 251);
		contentPane.add(scrollPane);
		
		tbAluno = new JTable();
		tbAluno.setModel(new DefaultTableModel(
			new Object[][] {
				{null, null, null, null, null},
			},
			new String[] {
				"ID", "Nome", "Matricula", "Email", "Data de cadastro"
			}
		));
		tbAluno.getColumnModel().getColumn(4).setPreferredWidth(163);
		scrollPane.setViewportView(tbAluno);
		
		btnAlterar = new JButton("Alterar");
		btnAlterar.setFont(new Font("Tahoma", Font.PLAIN, 11));
		btnAlterar.setBounds(10, 77, 73, 23);
		contentPane.add(btnAlterar);
	}
}
