package view;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JFormattedTextField;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import controller.CursoController;
import model.Curso;
import repositorio.DBConnection;

import java.awt.Font;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JTable;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;

import org.postgresql.util.PSQLException;
import javax.swing.JComboBox;
import java.awt.Color;
import javax.swing.JScrollPane;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.SwingConstants;

public class VCurso extends JFrame {

	private JPanel contentPane;
	private JTextField txtIdCurso;
	private JTextField txtNomeCurso;
	private JTextField textFieldCargH;
	private JTable tbCurso;
	private JTextField textFieldAluno;
	private JTextField txtDataCurso;
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					VCurso frame = new VCurso();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public VCurso() {
		setTitle("CADASTRO DE CURSO");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 579, 456);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		setLocationRelativeTo(contentPane);
		
		JButton btnSalvar = new JButton("Salvar");
		btnSalvar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Curso curso = new Curso();
				CursoController cieeController = new CursoController();
				
	
				
				curso.setId(Integer.valueOf(txtIdCurso.getText()));
				curso.setNome_curso(txtNomeCurso.getText());
				curso.setCarga_horaria_estagio(Integer.valueOf(textFieldCargH.getText()));
				curso.setData_cadastro(txtDataCurso.getText());									
				
				
				boolean resultado = cieeController.salvar(curso);
				if (resultado == true) {
					JOptionPane.showMessageDialog(null,
							"Dados gravados!",
					        "Processo concluído",
					        JOptionPane.INFORMATION_MESSAGE);
				}else {
					JOptionPane.showMessageDialog(null,
							"Houve um erro ao gravar os dados no banco de dados!",
					        "Impossível continuar",
					        JOptionPane.ERROR_MESSAGE);
				}
			}
		});
		btnSalvar.setBounds(48, 377, 117, 29);
		contentPane.add(btnSalvar);
		
		JButton btnFechar = new JButton("Fechar");
		btnFechar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		btnFechar.setBounds(381, 377, 117, 29);
		contentPane.add(btnFechar);
		
		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane.setBounds(6, 6, 551, 360);
		contentPane.add(tabbedPane);
		
		JPanel panel = new JPanel();
		tabbedPane.addTab("Cadastro", null, panel, null);
		
		JLabel lblIdCurso = new JLabel("Id");
		lblIdCurso.setBounds(22, 21, 12, 16);
		lblIdCurso.setFont(new Font("Tahoma", Font.PLAIN, 12));
		
		txtIdCurso = new JTextField();
		txtIdCurso.setBounds(21, 43, 95, 26);
		txtIdCurso.setColumns(10);
		
		JLabel lblDataCurso = new JLabel("Data cadastro");
		lblDataCurso.setBounds(202, 21, 82, 16);
		lblDataCurso.setFont(new Font("Tahoma", Font.PLAIN, 12));
		
		JLabel lblNomeCurso = new JLabel("Nome do Curso");
		lblNomeCurso.setBounds(22, 130, 94, 16);
		lblNomeCurso.setFont(new Font("Tahoma", Font.PLAIN, 13));
		
		txtNomeCurso = new JTextField();
		txtNomeCurso.setBounds(22, 148, 331, 26);
		txtNomeCurso.setColumns(10);
		panel.setLayout(null);
		panel.add(lblNomeCurso);
		panel.add(txtNomeCurso);
		panel.add(txtIdCurso);
		panel.add(lblIdCurso);
		panel.add(lblDataCurso);
		
		JLabel lblCoordenador = new JLabel("Cordenador ");
		lblCoordenador.setBounds(22, 185, 114, 14);
		lblCoordenador.setFont(new Font("Tahoma", Font.PLAIN, 13));
		panel.add(lblCoordenador);
		
		JComboBox comboBoxCoord = new JComboBox();
		comboBoxCoord.setBounds(22, 200, 331, 22);
		panel.add(comboBoxCoord);
		
		JLabel lblOrientador = new JLabel("Orientador");
		lblOrientador.setBounds(22, 247, 73, 14);
		lblOrientador.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblOrientador.setHorizontalAlignment(SwingConstants.LEFT);
		panel.add(lblOrientador);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setBounds(22, 262, 331, 23);
		panel.add(comboBox);
		
		JLabel lblCarga_horaria = new JLabel("Carga Horaria ");
		lblCarga_horaria.setBounds(386, 131, 94, 14);
		lblCarga_horaria.setFont(new Font("Tahoma", Font.PLAIN, 13));
		panel.add(lblCarga_horaria);
		
		textFieldCargH = new JTextField();
		textFieldCargH.setBounds(386, 150, 94, 23);
		panel.add(textFieldCargH);
		textFieldCargH.setColumns(10);
		
		Component horizontalStrut = Box.createHorizontalStrut(20);
		horizontalStrut.setBounds(10, 309, 495, 12);
		panel.add(horizontalStrut);
		
		JLabel lblNomeAluno = new JLabel("Nome do Aluno");
		lblNomeAluno.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblNomeAluno.setBounds(22, 80, 94, 14);
		panel.add(lblNomeAluno);
		
		textFieldAluno = new JTextField();
		textFieldAluno.setBounds(22, 94, 331, 20);
		panel.add(textFieldAluno);
		textFieldAluno.setColumns(10);
		
		txtDataCurso = new JTextField();
		txtDataCurso.setBounds(202, 43, 120, 26);
		panel.add(txtDataCurso);
		txtDataCurso.setColumns(10);
		
		JPanel panel_1 = new JPanel();
		tabbedPane.addTab("Listagem", null, panel_1, null);
		
		JButton btnConsultar = new JButton("Consultar");
		btnConsultar.setBounds(212, 5, 89, 23);
		btnConsultar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Connection connection;
				try {
					connection = DBConnection.getInstance().getConnection();
					System.out.println(connection.getCatalog());
					String sql = "select * from curso";
					PreparedStatement preparedStatement1 = connection.prepareStatement(sql);
								
					ResultSet rs = preparedStatement1.executeQuery();

					DefaultTableModel modelo = (DefaultTableModel) tbCurso.getModel();

					modelo.setNumRows(0);

					while (rs.next()) {
			
						modelo.addRow(new Object[]{rs.getString("id"), rs.getString("nome_curso"), rs.getString("carga_horaria_estagio"),rs.getString("data_cadastro")});

					}
		
					rs.close();
					connection.close();
			

				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}				
					

			}
			
	});
		panel_1.setLayout(null);
		panel_1.add(btnConsultar);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 48, 526, 273);
		panel_1.add(scrollPane);
		
		tbCurso = new JTable();
		tbCurso.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				
				int linha = tbCurso.getSelectedRow();
								
			
				txtIdCurso.setText(tbCurso.getValueAt(linha, 1).toString());
				txtNomeCurso.setText(tbCurso.getValueAt(linha, 2).toString());
				textFieldCargH.setText(tbCurso.getValueAt(linha, 3).toString());
				txtDataCurso.setText(tbCurso.getValueAt(linha, 4).toString());
					
			}
		});
		tbCurso.setFont(new Font("Tahoma", Font.PLAIN, 10));
		tbCurso.setModel(new DefaultTableModel(
			new Object[][] {
				{null, null, null, null, null, null},
			},
			new String[] {
				"ID", "NOME DO CURSO", "CARGA HORARIA", "DATA DE CADASTRO", "COORDENADOR", "ORIENTADOR"
			}
		) {
			Class[] columnTypes = new Class[] {
				Integer.class, Object.class, Object.class, Object.class, Object.class, Object.class
			};
			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
		});
		tbCurso.getColumnModel().getColumn(1).setPreferredWidth(155);
		tbCurso.getColumnModel().getColumn(3).setPreferredWidth(128);
		tbCurso.getColumnModel().getColumn(4).setPreferredWidth(135);
		tbCurso.getColumnModel().getColumn(5).setPreferredWidth(162);
		scrollPane.setViewportView(tbCurso);
		
		JButton btnAlterar = new JButton("Alterar");
		btnAlterar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Connection connection;
				
				Curso curso = new Curso();
				CursoController cursoController = new CursoController();
	
				
				curso.setId(Integer.valueOf(txtIdCurso.getText()));
				curso.setNome_curso(txtNomeCurso.getText());
				curso.setCarga_horaria_estagio(Integer.valueOf(textFieldCargH.getText()));
				curso.setData_cadastro(txtDataCurso.getText());									
												
								
				boolean resultado = cursoController.alterar(curso);
				if (resultado == true) {
					JOptionPane.showMessageDialog(null,
							"Dados gravados!",
					        "Processo concluído",
					        JOptionPane.INFORMATION_MESSAGE);
				}else {
					JOptionPane.showMessageDialog(null,
							"Houve um erro ao gravar os dados no banco de dados!",
					        "Impossível continuar",
					        JOptionPane.ERROR_MESSAGE);
				}
			}
		});

		btnAlterar.setBounds(161, 377, 117, 29);
		contentPane.add(btnAlterar);
		
		JButton btnExcluir = new JButton("Excluir");
		btnExcluir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			
			Connection connection;
			
			Curso curso = new Curso();
			CursoController cursoController = new CursoController();
			
	
			
			curso.setId(Integer.valueOf(txtIdCurso.getText()));
			curso.setNome_curso(txtNomeCurso.getText());
			curso.setCarga_horaria_estagio(Integer.valueOf(textFieldCargH.getText()));
			curso.setData_cadastro(txtDataCurso.getText());									
							
			boolean resultado = cursoController.excluir(curso);
			if (resultado == true) {
				JOptionPane.showMessageDialog(null,
						"Excluido com sucesso!",
				        "Processo concluído",
				        JOptionPane.INFORMATION_MESSAGE);
			}else {
				JOptionPane.showMessageDialog(null,
						"Houve um erro ao gravar os dados no banco de dados!",
				        "Impossível continuar",
				        JOptionPane.ERROR_MESSAGE);
			}
		}
	});
		btnExcluir.setBounds(271, 377, 117, 29);
		contentPane.add(btnExcluir);
	}
}