package view;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import javax.swing.AbstractButton;
import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JFormattedTextField;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;


import controller.ConcedenteController;
import model.Concedente;
import repositorio.DBConnection;

import java.awt.Font;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JTable;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;

import org.postgresql.util.PSQLException;
import javax.swing.JComboBox;
import java.awt.Color;
import javax.swing.JScrollPane;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.SwingConstants;

public class VConcedente extends JFrame {

	private JPanel contentPane;
	private JTable tbConcedente;
	private JTextField textId;
	private JTextField textNumConvenio;
	private JTextField textRazaoSocial;
	private JTextField textNomeFantasia;
	private JTextField textRespEstagio;
	private JTextField textSupervisorEstagio;
	private JTextField textEmail;
	private JTextField txtDataCadastro;
	private JTextField txtInicioConvenio;
	private JTextField txtFimConvenio;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					VConcedente frame = new VConcedente();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public VConcedente() {
		setTitle("Cadastro Concedente");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 685, 417);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		setLocationRelativeTo(contentPane);
		
		JButton btnSalvar = new JButton("Salvar");
		btnSalvar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Concedente concedente = new Concedente();
				ConcedenteController cieeController = new ConcedenteController();
				
				concedente.setId(Integer.valueOf(textId.getText()));
				concedente.setNumero_convenio(Integer.valueOf(textNumConvenio.getText()));
				concedente.setRazao_social(textRazaoSocial.getText());
				concedente.setNome_fantasia(textNomeFantasia.getText());
				concedente.setResponsavel_estagio(textRespEstagio.getText());
				concedente.setSupervisor_estagio(textSupervisorEstagio.getText());
				concedente.setData_cadastro(txtDataCadastro.getText());
				concedente.setInicio_convenio(txtInicioConvenio.getText());
				concedente.setFim_convenio(txtFimConvenio.getText());					
			

				
				boolean resultado = cieeController.salvar(concedente);
				if (resultado == true) {
					JOptionPane.showMessageDialog(null,
							"Dados gravados!",
					        "Processo concluído",
					        JOptionPane.INFORMATION_MESSAGE);
				}else {
					JOptionPane.showMessageDialog(null,
							"Houve um erro ao gravar os dados no banco de dados!",
					        "Impossível continuar",
					        JOptionPane.ERROR_MESSAGE);
				}
			}
		});
		btnSalvar.setBounds(160, 337, 117, 29);
		contentPane.add(btnSalvar);
		
		JButton btnFechar = new JButton("Fechar");
		btnFechar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		btnFechar.setBounds(493, 337, 117, 29);
		contentPane.add(btnFechar);
		
		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane.setBounds(6, 6, 653, 308);
		contentPane.add(tabbedPane);
		
		JPanel panel = new JPanel();
		tabbedPane.addTab("Cadastro", null, panel, null);
		panel.setLayout(null);
		
		JPanel txtDtCadastro = new JPanel();
		txtDtCadastro.setLayout(null);
		txtDtCadastro.setBounds(0, 0, 662, 350);
		panel.add(txtDtCadastro);
		
		JLabel lblIDConc = new JLabel("ID");
		lblIDConc.setBounds(10, 11, 46, 14);
		txtDtCadastro.add(lblIDConc);
		
		textId = new JTextField();
		textId.setColumns(10);
		textId.setBounds(10, 27, 46, 20);
		txtDtCadastro.add(textId);
		
		JLabel lblDataCadCon = new JLabel("Data de Cadastro");
		lblDataCadCon.setBounds(222, 11, 105, 14);
		txtDtCadastro.add(lblDataCadCon);
		
		Component horizontalStrut_1 = Box.createHorizontalStrut(20);
		horizontalStrut_1.setBounds(10, 351, 449, 12);
		txtDtCadastro.add(horizontalStrut_1);
		
		JButton btnNewButton_1 = new JButton("Fechar");
		btnNewButton_1.setBounds(343, 374, 117, 29);
		txtDtCadastro.add(btnNewButton_1);
		
		JButton btnNewButton_3 = new JButton("Excluir");
		btnNewButton_3.setBounds(233, 374, 117, 29);
		txtDtCadastro.add(btnNewButton_3);
		
		JButton btnNewButton_2 = new JButton("Alterar");
		btnNewButton_2.setBounds(123, 374, 117, 29);
		txtDtCadastro.add(btnNewButton_2);
		
		JButton btnNewButton = new JButton("Salvar");
		btnNewButton.setBounds(10, 374, 117, 29);
		txtDtCadastro.add(btnNewButton);
		
		JLabel lblNumConv = new JLabel("Numero Convênio");
		lblNumConv.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNumConv.setBounds(10, 68, 117, 14);
		txtDtCadastro.add(lblNumConv);
		
		textNumConvenio = new JTextField();
		textNumConvenio.setColumns(10);
		textNumConvenio.setBounds(10, 83, 117, 20);
		txtDtCadastro.add(textNumConvenio);
		
		JLabel lblRazaoSocial = new JLabel("Razão Social");
		lblRazaoSocial.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblRazaoSocial.setBounds(149, 68, 93, 14);
		txtDtCadastro.add(lblRazaoSocial);
		
		textRazaoSocial = new JTextField();
		textRazaoSocial.setColumns(10);
		textRazaoSocial.setBounds(149, 83, 159, 20);
		txtDtCadastro.add(textRazaoSocial);
		
		JLabel lblNomeFantasia = new JLabel("Nome Fantasia");
		lblNomeFantasia.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNomeFantasia.setBounds(10, 118, 93, 14);
		txtDtCadastro.add(lblNomeFantasia);
		
		textNomeFantasia = new JTextField();
		textNomeFantasia.setColumns(10);
		textNomeFantasia.setBounds(10, 132, 298, 20);
		txtDtCadastro.add(textNomeFantasia);
		
		JLabel lblRespEstagio = new JLabel("Responsavel pelo Estagio");
		lblRespEstagio.setBounds(10, 173, 143, 14);
		txtDtCadastro.add(lblRespEstagio);
		
		textRespEstagio = new JTextField();
		textRespEstagio.setColumns(10);
		textRespEstagio.setBounds(10, 187, 298, 20);
		txtDtCadastro.add(textRespEstagio);
		
		JLabel lblSuperEstagio = new JLabel("Supervisor de Estagio");
		lblSuperEstagio.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblSuperEstagio.setBounds(318, 172, 143, 14);
		txtDtCadastro.add(lblSuperEstagio);
		
		textSupervisorEstagio = new JTextField();
		textSupervisorEstagio.setColumns(10);
		textSupervisorEstagio.setBounds(318, 187, 298, 20);
		txtDtCadastro.add(textSupervisorEstagio);
		
		JLabel lblInicioConvenio = new JLabel("Inicio do Convênio");
		lblInicioConvenio.setBounds(10, 227, 93, 14);
		txtDtCadastro.add(lblInicioConvenio);
		
		JLabel lblFimConvenio = new JLabel("Fim do Convênio");
		lblFimConvenio.setBounds(116, 227, 93, 14);
		txtDtCadastro.add(lblFimConvenio);
		
		JLabel lblTelefoneCon = new JLabel("Telefone");
		lblTelefoneCon.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblTelefoneCon.setBounds(330, 68, 71, 14);
		txtDtCadastro.add(lblTelefoneCon);
		
		JLabel lblEmailCon = new JLabel("Email");
		lblEmailCon.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblEmailCon.setBounds(330, 118, 46, 14);
		txtDtCadastro.add(lblEmailCon);
		
		textEmail = new JTextField();
		textEmail.setColumns(10);
		textEmail.setBounds(330, 132, 152, 20);
		txtDtCadastro.add(textEmail);
		
		JFormattedTextField txtTelefone = new JFormattedTextField();
		txtTelefone.setBounds(330, 83, 152, 20);
		txtDtCadastro.add(txtTelefone);
		
		txtDataCadastro = new JTextField();
		txtDataCadastro.setBounds(222, 27, 105, 20);
		txtDtCadastro.add(txtDataCadastro);
		txtDataCadastro.setColumns(10);
		
		txtInicioConvenio = new JTextField();
		txtInicioConvenio.setBounds(10, 241, 86, 20);
		txtDtCadastro.add(txtInicioConvenio);
		txtInicioConvenio.setColumns(10);
		
		txtFimConvenio = new JTextField();
		txtFimConvenio.setBounds(116, 241, 86, 20);
		txtDtCadastro.add(txtFimConvenio);
		txtFimConvenio.setColumns(10);
		
		JPanel panel_1 = new JPanel();
		tabbedPane.addTab("Listagem", null, panel_1, null);
		
		JButton btnConsultar = new JButton("Consultar");
		btnConsultar.setBounds(212, 5, 89, 23);
		btnConsultar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Connection connection;
				try {
					connection = DBConnection.getInstance().getConnection();
					System.out.println(connection.getCatalog());
					String sql = "select * from concedente";
					PreparedStatement preparedStatement1 = connection.prepareStatement(sql);
								
					ResultSet rs = preparedStatement1.executeQuery();

					DefaultTableModel modelo = (DefaultTableModel) tbConcedente.getModel();

					modelo.setNumRows(0);

					while (rs.next()) {
						modelo.addRow(new Object[]{rs.getString("id"), rs.getString("numero_convenio"), rs.getString("razao_social"), rs.getString("responsavel_estagio"), rs.getString("supervisor_estagio"), rs.getString("inicio_convenio"), rs.getString("fim_convenio"), rs.getString("data_cadastro")});

					}
		
					rs.close();
					connection.close();
			

				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}				
					

			}
			
	});
		panel_1.setLayout(null);
		panel_1.add(btnConsultar);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 48, 638, 221);
		panel_1.add(scrollPane);
		
		tbConcedente = new JTable();
		tbConcedente.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				
				int linha = tbConcedente.getSelectedRow();
				
								
				textId.setText(tbConcedente.getValueAt(linha, 0).toString());
				textNumConvenio.setText(tbConcedente.getValueAt(linha, 1).toString());
				textRazaoSocial.setText(tbConcedente.getValueAt(linha, 2).toString());
				textNomeFantasia.setText(tbConcedente.getValueAt(linha, 3).toString());
				textRespEstagio.setText(tbConcedente.getValueAt(linha, 4).toString());
				textSupervisorEstagio.setText(tbConcedente.getValueAt(linha, 5).toString());
				txtInicioConvenio.setText(tbConcedente.getValueAt(linha, 6).toString());
				txtFimConvenio.setText(tbConcedente.getValueAt(linha, 7).toString());
				txtDataCadastro.setText(tbConcedente.getValueAt(linha, 8).toString());
				
			
					
			}
		});
		tbConcedente.setFont(new Font("Tahoma", Font.PLAIN, 12));
		tbConcedente.setModel(new DefaultTableModel(
			new Object[][] {
				{null, null, null, null, null, null, null, null, null},
			},
			new String[] {
				"ID", "NUMERO CONVENIO", "RAZAO SOCIAL", "NOME FANTASIA", "RESPONSAVEL", "SUPERVISOR", "FIM CONVENIO", "INICIO CONVENIO", "DATA DE CADASTRO"
			}
		) {
			Class[] columnTypes = new Class[] {
				Integer.class, Object.class, Object.class, Object.class, Object.class, Object.class, Object.class, Object.class, Object.class
			};
			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
		});
		tbConcedente.getColumnModel().getColumn(0).setPreferredWidth(155);
		tbConcedente.getColumnModel().getColumn(1).setPreferredWidth(135);
		tbConcedente.getColumnModel().getColumn(2).setPreferredWidth(162);
		tbConcedente.getColumnModel().getColumn(3).setPreferredWidth(128);
		tbConcedente.getColumnModel().getColumn(4).setPreferredWidth(155);
		tbConcedente.getColumnModel().getColumn(5).setPreferredWidth(135);
		tbConcedente.getColumnModel().getColumn(6).setPreferredWidth(162);
		tbConcedente.getColumnModel().getColumn(7).setPreferredWidth(128);
		tbConcedente.getColumnModel().getColumn(8).setPreferredWidth(128);
		
		scrollPane.setViewportView(tbConcedente);
		
		JButton btnAlterar = new JButton("Alterar");
		btnAlterar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Connection connection;
				
				Concedente concedente = new Concedente();
				ConcedenteController cieeController = new ConcedenteController();
				
								
				concedente.setId(Integer.valueOf(textId.getText()));
				concedente.setNumero_convenio(Integer.valueOf(textNumConvenio.getText()));
				concedente.setRazao_social(textRazaoSocial.getText());
				concedente.setNome_fantasia(textNomeFantasia.getText());
				concedente.setResponsavel_estagio(textRespEstagio.getText());
				concedente.setSupervisor_estagio(textSupervisorEstagio.getText());
				concedente.setData_cadastro(txtDataCadastro.getText());
				concedente.setInicio_convenio(txtInicioConvenio.getText());
				concedente.setFim_convenio(txtFimConvenio.getText());							
								
				boolean resultado = cieeController.alterar(concedente);
				if (resultado == true) {
					JOptionPane.showMessageDialog(null,
							"Dados gravados!",
					        "Processo concluído",
					        JOptionPane.INFORMATION_MESSAGE);
				}else {
					JOptionPane.showMessageDialog(null,
							"Houve um erro ao gravar os dados no banco de dados!",
					        "Impossível continuar",
					        JOptionPane.ERROR_MESSAGE);
				}
			}
		});

		btnAlterar.setBounds(273, 337, 117, 29);
		contentPane.add(btnAlterar);
		
		JButton btnExcluir = new JButton("Excluir");
		btnExcluir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			
			Connection connection;
			
			Concedente concedente = new Concedente();
			ConcedenteController cieeController = new ConcedenteController();
			
			
			
			concedente.setId(Integer.valueOf(textId.getText()));
			concedente.setNumero_convenio(Integer.valueOf(textNumConvenio.getText()));
			concedente.setRazao_social(textRazaoSocial.getText());
			concedente.setNome_fantasia(textNomeFantasia.getText());
			concedente.setResponsavel_estagio(textRespEstagio.getText());
			concedente.setSupervisor_estagio(textSupervisorEstagio.getText());
			concedente.setData_cadastro(txtDataCadastro.getText());
			concedente.setInicio_convenio(txtInicioConvenio.getText());
			concedente.setFim_convenio(txtFimConvenio.getText());							
							
			boolean resultado = cieeController.excluir(concedente);
			if (resultado == true) {
				JOptionPane.showMessageDialog(null,
						"Excluido com sucesso!",
				        "Processo concluído",
				        JOptionPane.INFORMATION_MESSAGE);
			}else {
				JOptionPane.showMessageDialog(null,
						"Houve um erro ao gravar os dados no banco de dados!",
				        "Impossível continuar",
				        JOptionPane.ERROR_MESSAGE);
			}
		}
	});
		btnExcluir.setBounds(383, 337, 117, 29);
		contentPane.add(btnExcluir);
		
		Component horizontalStrut = Box.createHorizontalStrut(20);
		horizontalStrut.setBounds(6, 314, 653, 12);
		contentPane.add(horizontalStrut);
	}
}