package view;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JFormattedTextField;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import controller.AlunoTelefoneController;
import controller.TipoTelefoneController;
import model.AlunoTelefone;
import model.TipoTelefone;
import repositorio.DBConnection;
import repositorio.TipoTelefoneRepositorio;

import java.awt.Font;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JTable;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;

import org.postgresql.util.PSQLException;
import javax.swing.JComboBox;
import java.awt.Color;
import javax.swing.JScrollPane;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.SwingConstants;
import javax.swing.event.AncestorListener;
import javax.swing.event.AncestorEvent;

public class VAlunosTelefone extends JFrame {

	private JPanel contentPane;
	private JTextField txtId;
	private JTextField txtTelefone;
	private JTable tbAlunoTelefone;
	//private JComboBox cbTipoTelefone;
	private javax.swing.JComboBox<String> cbTipoTelefone;
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					VAlunosTelefone frame = new VAlunosTelefone();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public VAlunosTelefone() {
		setTitle("Cadastro Telefone");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 583, 307);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		setLocationRelativeTo(contentPane);
		
		JButton btnSalvar = new JButton("Salvar");
		btnSalvar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				AlunoTelefone alunotelefone = new AlunoTelefone();
				AlunoTelefoneController cieeController = new AlunoTelefoneController();
										
				alunotelefone.setId(Integer.valueOf(txtId.getText()));
				alunotelefone.setTelefone(txtTelefone.getText());
				alunotelefone.setTipoTelefone(cbTipoTelefone.getSelectedItem().toString());
				
				
				boolean resultado = cieeController.salvar(alunotelefone);
				if (resultado == true) {
					JOptionPane.showMessageDialog(null,
							"Dados gravados!",
					        "Processo concluído",
					        JOptionPane.INFORMATION_MESSAGE);
				}else {
					JOptionPane.showMessageDialog(null,
							"Houve um erro ao gravar os dados no banco de dados!",
					        "Impossível continuar",
					        JOptionPane.ERROR_MESSAGE);
				}
			}
		});
		btnSalvar.setBounds(46, 206, 117, 29);
		contentPane.add(btnSalvar);
		
		JButton btnFechar = new JButton("Fechar");
		btnFechar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		btnFechar.setBounds(379, 206, 117, 29);
		contentPane.add(btnFechar);
		
		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane.setBounds(6, 6, 551, 189);
		contentPane.add(tabbedPane);
		
		JPanel panel = new JPanel();
		tabbedPane.addTab("Cadastro", null, panel, null);
		
		JLabel lblId = new JLabel("Id");
		lblId.setBounds(22, 21, 12, 16);
		lblId.setFont(new Font("Tahoma", Font.PLAIN, 12));
		
		txtId = new JTextField();
		txtId.setBounds(21, 43, 95, 26);
		txtId.setColumns(10);
		
		JLabel lblTipoTelefone = new JLabel("Tipo Telefone");
		lblTipoTelefone.setBounds(389, 21, 82, 16);
		lblTipoTelefone.setFont(new Font("Tahoma", Font.PLAIN, 12));
		
		txtTelefone = new JTextField();
		txtTelefone.setBounds(144, 44, 193, 26);
		txtTelefone.setColumns(10);
		
		JLabel lblNumero_matricula = new JLabel("Telefone");
		lblNumero_matricula.setBounds(144, 21, 95, 16);
		lblNumero_matricula.setFont(new Font("Tahoma", Font.PLAIN, 12));
		panel.setLayout(null);
		panel.add(txtId);
		panel.add(lblId);
		panel.add(lblNumero_matricula);
		panel.add(lblTipoTelefone);
		panel.add(txtTelefone);
		
		Component horizontalStrut = Box.createHorizontalStrut(20);
		horizontalStrut.setBounds(10, 115, 530, 12);
		panel.add(horizontalStrut);
		
		final JComboBox cbTipoTelefone = new JComboBox();
		cbTipoTelefone.addAncestorListener(new AncestorListener() {
			public void ancestorAdded(AncestorEvent event) {
				
				TipoTelefoneRepositorio tipotelefone = new TipoTelefoneRepositorio();
				List<TipoTelefone>lista = tipotelefone.buscarTodos();
				
				cbTipoTelefone.removeAll();
				
				for(TipoTelefone f:lista) {
					cbTipoTelefone.addItem(f);
				}
								
				
			}

			public void ancestorRemoved(AncestorEvent event) {
				// TODO Auto-generated method stub
				
			}

			public void ancestorMoved(AncestorEvent event) {
				// TODO Auto-generated method stub
				
			}
			
		});
		cbTipoTelefone.setBounds(376, 45, 135, 22);
		panel.add(cbTipoTelefone);
		
		JPanel panel_1 = new JPanel();
		tabbedPane.addTab("Listagem", null, panel_1, null);
		
		JButton btnConsultar = new JButton("Consultar");
		btnConsultar.setBounds(212, 5, 89, 23);
		btnConsultar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Connection connection;
				try {
					connection = DBConnection.getInstance().getConnection();
					System.out.println(connection.getCatalog());
					String sql = "select * from alunotelefone";
					PreparedStatement preparedStatement1 = connection.prepareStatement(sql);
								
					ResultSet rs = preparedStatement1.executeQuery();

					DefaultTableModel modelo = (DefaultTableModel) tbAlunoTelefone.getModel();

					modelo.setNumRows(0);

					while (rs.next()) {
			
						modelo.addRow(new Object[]{rs.getString("id"), rs.getString("telefone"),  rs.getString("tipotelefone")});

					}
		
					rs.close();
					connection.close();
			

				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}				
					

			}
			
	});
		panel_1.setLayout(null);
		panel_1.add(btnConsultar);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 48, 526, 113);
		panel_1.add(scrollPane);
		
		tbAlunoTelefone = new JTable();
		tbAlunoTelefone.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				
				int linha = tbAlunoTelefone.getSelectedRow();
				
						
				txtId.setText(tbAlunoTelefone.getValueAt(linha, 0).toString());
				txtTelefone.setText(tbAlunoTelefone.getValueAt(linha, 1).toString());
				cbTipoTelefone.setSelectedItem(tbAlunoTelefone.getValueAt(linha, 3).toString());
					
			}
		});
		tbAlunoTelefone.setFont(new Font("Tahoma", Font.PLAIN, 10));
		tbAlunoTelefone.setModel(new DefaultTableModel(
			new Object[][] {
				{null, null, null},
			},
			new String[] {
				"ID", "TELEFONE", "TIPO DE TELEFONE"
			}
		) {
			Class[] columnTypes = new Class[] {
				Integer.class, Object.class, Object.class
			};
			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
		});
		tbAlunoTelefone.getColumnModel().getColumn(0).setPreferredWidth(155);
		tbAlunoTelefone.getColumnModel().getColumn(1).setPreferredWidth(135);
		tbAlunoTelefone.getColumnModel().getColumn(2).setPreferredWidth(110);
		scrollPane.setViewportView(tbAlunoTelefone);
		
		JButton btnAlterar = new JButton("Alterar");
		btnAlterar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Connection connection;
				
				AlunoTelefone alunotelefone = new AlunoTelefone();
				AlunoTelefoneController cieeController = new AlunoTelefoneController();
				
							
				alunotelefone.setId(Integer.valueOf(txtId.getText()));
				alunotelefone.setTelefone(txtTelefone.getText());
								
								
				boolean resultado = cieeController.alterar(alunotelefone);
				if (resultado == true) {
					JOptionPane.showMessageDialog(null,
							"Dados gravados!",
					        "Processo concluído",
					        JOptionPane.INFORMATION_MESSAGE);
				}else {
					JOptionPane.showMessageDialog(null,
							"Houve um erro ao gravar os dados no banco de dados!",
					        "Impossível continuar",
					        JOptionPane.ERROR_MESSAGE);
				}
			}
		});

		btnAlterar.setBounds(159, 206, 117, 29);
		contentPane.add(btnAlterar);
		
		JButton btnExcluir = new JButton("Excluir");
		btnExcluir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			
			Connection connection;
			
			AlunoTelefone alunotelefone = new AlunoTelefone();
			AlunoTelefoneController cieeController = new AlunoTelefoneController();

			alunotelefone.setId(Integer.valueOf(txtId.getText()));
			alunotelefone.setTelefone(txtTelefone.getText());
							
			boolean resultado = cieeController.excluir(alunotelefone);
			if (resultado == true) {
				JOptionPane.showMessageDialog(null,
						"Excluido com sucesso!",
				        "Processo concluído",
				        JOptionPane.INFORMATION_MESSAGE);
			}else {
				JOptionPane.showMessageDialog(null,
						"Houve um erro ao gravar os dados no banco de dados!",
				        "Impossível continuar",
				        JOptionPane.ERROR_MESSAGE);
			}
		}
	});
		btnExcluir.setBounds(269, 206, 117, 29);
		contentPane.add(btnExcluir);
	}
}