package view;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JFormattedTextField;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import controller.AgMediadorController;
import model.AgenteMediador;
import repositorio.DBConnection;

import java.awt.Font;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JTable;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;

import org.postgresql.util.PSQLException;
import javax.swing.JComboBox;
import java.awt.Color;
import javax.swing.JScrollPane;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.SwingConstants;

public class VAgenteMediador extends JFrame {

	private JPanel contentPane;
	private JTextField txtIdMed;
	private JTextField txtNomeMed;
	private JFormattedTextField txtDataMed;
	private JTable tbMediador;
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					VAgenteMediador frame = new VAgenteMediador();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public VAgenteMediador() {
		setTitle(" Agente Mediador");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 583, 296);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		setLocationRelativeTo(contentPane);
		
		JButton btnSalvar = new JButton("Salvar");
		btnSalvar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				AgenteMediador agentemediador = new AgenteMediador();
				AgMediadorController cieeController = new AgMediadorController();
				
				DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
				LocalDate data = LocalDate.parse(txtDataMed.getText(), formatter);
				
				agentemediador.setId(Integer.valueOf(txtIdMed.getText()));
				agentemediador.setNome(txtNomeMed.getText());
				agentemediador.setData_cadastro(data);								
				
				boolean resultado = cieeController.salvar(agentemediador);
				if (resultado == true) {
					JOptionPane.showMessageDialog(null,
							"Dados gravados!",
					        "Processo concluído",
					        JOptionPane.INFORMATION_MESSAGE);
				}else {
					JOptionPane.showMessageDialog(null,
							"Houve um erro ao gravar os dados no banco de dados!",
					        "Impossível continuar",
					        JOptionPane.ERROR_MESSAGE);
				}
			}
		});
		btnSalvar.setBounds(51, 208, 117, 29);
		contentPane.add(btnSalvar);
		
		JButton btnFechar = new JButton("Fechar");
		btnFechar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		btnFechar.setBounds(384, 208, 117, 29);
		contentPane.add(btnFechar);
		
		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane.setBounds(6, 6, 551, 191);
		contentPane.add(tabbedPane);
		
		JPanel panel = new JPanel();
		tabbedPane.addTab("Cadastro", null, panel, null);
		
		JLabel lblIdMed = new JLabel("Id");
		lblIdMed.setBounds(22, 21, 12, 16);
		lblIdMed.setFont(new Font("Tahoma", Font.PLAIN, 12));
		
		txtIdMed = new JTextField();
		txtIdMed.setBounds(21, 43, 95, 26);
		txtIdMed.setColumns(10);
		
		JLabel lblDataM = new JLabel("Data cadastro");
		lblDataM.setBounds(178, 21, 82, 16);
		lblDataM.setFont(new Font("Tahoma", Font.PLAIN, 12));
		
		txtDataMed = new JFormattedTextField();
		txtDataMed.setBounds(178, 43, 114, 26);
		txtDataMed.setHorizontalAlignment(SwingConstants.CENTER);
		txtDataMed.setText("__/__/__");
		
		JLabel lblNome = new JLabel("Nome Mediador");
		lblNome.setBounds(22, 96, 94, 16);
		lblNome.setFont(new Font("Tahoma", Font.PLAIN, 13));
		
		txtNomeMed = new JTextField();
		txtNomeMed.setBounds(22, 114, 351, 26);
		txtNomeMed.setColumns(10);
		panel.setLayout(null);
		panel.add(lblNome);
		panel.add(txtNomeMed);
		panel.add(txtIdMed);
		panel.add(lblIdMed);
		panel.add(lblDataM);
		panel.add(txtDataMed);
		
		Component horizontalStrut = Box.createHorizontalStrut(20);
		horizontalStrut.setBounds(10, 163, 530, 12);
		panel.add(horizontalStrut);
		
		JPanel panel_1 = new JPanel();
		tabbedPane.addTab("Listagem", null, panel_1, null);
		
		JButton btnConsultar = new JButton("Consultar");
		btnConsultar.setBounds(212, 5, 89, 23);
		btnConsultar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Connection connection;
				try {
					connection = DBConnection.getInstance().getConnection();
					System.out.println(connection.getCatalog());
					String sql = "select * from agentemediador";
					PreparedStatement preparedStatement1 = connection.prepareStatement(sql);
								
					ResultSet rs = preparedStatement1.executeQuery();

					DefaultTableModel modelo = (DefaultTableModel) tbMediador.getModel();

					modelo.setNumRows(0);

					while (rs.next()) {
			
						modelo.addRow(new Object[]{rs.getString("id"), rs.getString("nome"),rs.getDate("data_cadastro")});

					}
		
					rs.close();
					connection.close();
			

				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}				
					

			}
			
	});
		panel_1.setLayout(null);
		panel_1.add(btnConsultar);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 48, 526, 273);
		panel_1.add(scrollPane);
		
		tbMediador = new JTable();
		tbMediador.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				
				int linha = tbMediador.getSelectedRow();
				
				
				/*DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
				LocalDate data = LocalDate.parse(txtData.getText(), formatter);*/
				
				txtIdMed.setText(tbMediador.getValueAt(linha, 0).toString());
				txtNomeMed.setText(tbMediador.getValueAt(linha, 1).toString());
				txtDataMed.setText(tbMediador.getValueAt(linha, 3).toString());
					
			}
		});
		tbMediador.setFont(new Font("Tahoma", Font.PLAIN, 10));
		tbMediador.setModel(new DefaultTableModel(
			new Object[][] {
				{null, null, null},
			},
			new String[] {
				"ID", "NOME DO MEDIADOR", "DATA DE CADASTRO"
			}
		) {
			Class[] columnTypes = new Class[] {
				Integer.class, Object.class, Object.class
			};
			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
		});
		tbMediador.getColumnModel().getColumn(1).setPreferredWidth(323);
		tbMediador.getColumnModel().getColumn(2).setPreferredWidth(128);

		scrollPane.setViewportView(tbMediador);
		
		JButton btnAlterar = new JButton("Alterar");
		btnAlterar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Connection connection;
				
				AgenteMediador agentemediador = new AgenteMediador();
				AgMediadorController cieeController = new AgMediadorController();
				
				DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
				LocalDate data = LocalDate.parse(txtDataMed.getText(), formatter);
				
				
				agentemediador.setId(Integer.valueOf(txtIdMed.getText()));
				agentemediador.setNome(txtNomeMed.getText());
				agentemediador.setData_cadastro(data);							
								
				boolean resultado = cieeController.alterar(agentemediador);
				if (resultado == true) {
					JOptionPane.showMessageDialog(null,
							"Dados gravados!",
					        "Processo concluído",
					        JOptionPane.INFORMATION_MESSAGE);
				}else {
					JOptionPane.showMessageDialog(null,
							"Houve um erro ao gravar os dados no banco de dados!",
					        "Impossível continuar",
					        JOptionPane.ERROR_MESSAGE);
				}
			}
		});

		btnAlterar.setBounds(164, 208, 117, 29);
		contentPane.add(btnAlterar);
		
		JButton btnExcluir = new JButton("Excluir");
		btnExcluir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			
			Connection connection;
			
			AgenteMediador agentemediador = new AgenteMediador();
			AgMediadorController cieeController = new AgMediadorController();
			
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
			LocalDate data = LocalDate.parse(txtDataMed.getText(), formatter);
			
			agentemediador.setId(Integer.valueOf(txtIdMed.getText()));
			agentemediador.setNome(txtNomeMed.getText());
			agentemediador.setData_cadastro(data);								
							
			boolean resultado = cieeController.excluir(agentemediador);
			if (resultado == true) {
				JOptionPane.showMessageDialog(null,
						"Excluido com sucesso!",
				        "Processo concluído",
				        JOptionPane.INFORMATION_MESSAGE);
			}else {
				JOptionPane.showMessageDialog(null,
						"Houve um erro ao gravar os dados no banco de dados!",
				        "Impossível continuar",
				        JOptionPane.ERROR_MESSAGE);
			}
		}
	});
		btnExcluir.setBounds(274, 208, 117, 29);
		contentPane.add(btnExcluir);
	}
}