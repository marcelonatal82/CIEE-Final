package view;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JFormattedTextField;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import controller.ServidorController;
import model.Curso;
import model.Servidor;
import model.TipoTelefone;
import repositorio.CursoRepositorio;
import repositorio.DBConnection;
import repositorio.TipoTelefoneRepositorio;

import java.awt.Font;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JTable;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;

import org.postgresql.util.PSQLException;
import javax.swing.JComboBox;
import java.awt.Color;
import javax.swing.JScrollPane;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.SwingConstants;
import javax.swing.event.AncestorListener;
import javax.swing.event.AncestorEvent;

public class VServidor extends JFrame {

	private JPanel contentPane;
	private JTextField txtIdServidor;
	private JTextField txtMatricula;
	private JFormattedTextField txtDataServidor;
	private JTextField textEmailServidor;	
	private JTextField textFieldNomeServidor;
	private JTextField textField;
	private JTextField textFieldUF;
	private JTextField textFieldTelefoneServidor;
	private JTable tbServidor;
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					VServidor frame = new VServidor();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public VServidor() {
		setTitle("CADASTRO DE SERVIDOR");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 624, 456);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		setLocationRelativeTo(contentPane);
		
		JButton btnSalvar = new JButton("Salvar");
		btnSalvar.setBounds(48, 377, 117, 29);
		btnSalvar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Servidor servidor = new Servidor();
				ServidorController cieeController = new ServidorController();
				
				DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
				LocalDate data = LocalDate.parse(txtDataServidor.getText(), formatter);
				
				servidor.setId(Integer.valueOf(txtIdServidor.getText()));
				servidor.setNome(textFieldNomeServidor.getText());
				servidor.setMatricula(txtMatricula.getText());
				servidor.setEmail(textEmailServidor.getText());
				servidor.setData_cadastro(data);								
				
				
				boolean resultado = cieeController.salvar(servidor);
				if (resultado == true) {
					JOptionPane.showMessageDialog(null,
							"Dados gravados!",
					        "Processo concluído",
					        JOptionPane.INFORMATION_MESSAGE);
				}else {
					JOptionPane.showMessageDialog(null,
							"Houve um erro ao gravar os dados no banco de dados!",
					        "Impossível continuar",
					        JOptionPane.ERROR_MESSAGE);
				}
			}
		});
		contentPane.setLayout(null);
		contentPane.add(btnSalvar);
		
		JButton btnFechar = new JButton("Fechar");
		btnFechar.setBounds(381, 377, 117, 29);
		btnFechar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		contentPane.add(btnFechar);
		
		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane.setBounds(6, 6, 551, 360);
		contentPane.add(tabbedPane);
		
		JPanel panel = new JPanel();
		tabbedPane.addTab("Cadastro", null, panel, null);
		
		JLabel lblIdServidor = new JLabel("Id");
		lblIdServidor.setBounds(22, 21, 12, 16);
		lblIdServidor.setFont(new Font("Tahoma", Font.PLAIN, 12));
		
		txtIdServidor = new JTextField();
		txtIdServidor.setBounds(21, 43, 95, 26);
		txtIdServidor.setColumns(10);
		
		JLabel lblDataServidor = new JLabel("Data cadastro");
		lblDataServidor.setBounds(202, 21, 82, 16);
		lblDataServidor.setFont(new Font("Tahoma", Font.PLAIN, 12));
		
		txtDataServidor = new JFormattedTextField();
		txtDataServidor.setBounds(202, 43, 114, 26);
		txtDataServidor.setHorizontalAlignment(SwingConstants.CENTER);
		
		JLabel lblMatricula = new JLabel("Matricula");
		lblMatricula.setBounds(22, 130, 94, 16);
		lblMatricula.setFont(new Font("Tahoma", Font.PLAIN, 13));
		
		txtMatricula = new JTextField();
		txtMatricula.setBounds(22, 148, 160, 26);
		txtMatricula.setColumns(10);
		panel.setLayout(null);
		panel.add(lblMatricula);
		panel.add(txtMatricula);
		panel.add(txtIdServidor);
		panel.add(lblIdServidor);
		panel.add(lblDataServidor);
		panel.add(txtDataServidor);
		
		JLabel lblCidade = new JLabel("Cidade");
		lblCidade.setBounds(22, 185, 114, 14);
		lblCidade.setFont(new Font("Tahoma", Font.PLAIN, 13));
		panel.add(lblCidade);
		
		JLabel lblCurso = new JLabel("Curso");
		lblCurso.setBounds(22, 247, 73, 14);
		lblCurso.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblCurso.setHorizontalAlignment(SwingConstants.LEFT);
		panel.add(lblCurso);
		
		final JComboBox cbCurso = new JComboBox();
		cbCurso.addAncestorListener(new AncestorListener() {
			public void ancestorAdded(AncestorEvent event) {
				
				CursoRepositorio curso = new CursoRepositorio();
				List<Curso> lista = curso.buscarTodos();
				
				cbCurso.removeAll();
				
				for(Curso f:lista) {
					cbCurso.addItem(f);
				}
						
			}
			public void ancestorMoved(AncestorEvent event) {
			}
			public void ancestorRemoved(AncestorEvent event) {
			}
		});
		cbCurso.setBounds(22, 262, 220, 23);
		panel.add(cbCurso);
		
		JLabel lblEmail = new JLabel("Email");
		lblEmail.setBounds(212, 131, 94, 14);
		lblEmail.setFont(new Font("Tahoma", Font.PLAIN, 13));
		panel.add(lblEmail);
		
		textEmailServidor = new JTextField();
		textEmailServidor.setBounds(212, 150, 193, 23);
		panel.add(textEmailServidor);
		textEmailServidor.setColumns(10);
		
		Component horizontalStrut = Box.createHorizontalStrut(20);
		horizontalStrut.setBounds(10, 309, 495, 12);
		panel.add(horizontalStrut);
		
		JLabel lblNomeServidor = new JLabel("Nome do Servidor");
		lblNomeServidor.setBounds(22, 80, 114, 14);
		lblNomeServidor.setFont(new Font("Tahoma", Font.PLAIN, 13));
		panel.add(lblNomeServidor);
		
		textFieldNomeServidor = new JTextField();
		textFieldNomeServidor.setBounds(22, 94, 331, 20);
		panel.add(textFieldNomeServidor);
		textFieldNomeServidor.setColumns(10);
		
		textField = new JTextField();
		textField.setBounds(22, 203, 193, 20);
		panel.add(textField);
		textField.setColumns(10);
		
		JLabel lblUF = new JLabel("UF");
		lblUF.setBounds(238, 186, 46, 14);
		panel.add(lblUF);
		
		textFieldUF = new JTextField();
		textFieldUF.setBounds(238, 203, 86, 20);
		panel.add(textFieldUF);
		textFieldUF.setColumns(10);
		
		JLabel lblTipoServidor = new JLabel("Tipo de Servidor");
		lblTipoServidor.setBounds(375, 80, 105, 14);
		lblTipoServidor.setFont(new Font("Tahoma", Font.PLAIN, 13));
		panel.add(lblTipoServidor);
		
		JComboBox comboBoxTipoServidor = new JComboBox();
		comboBoxTipoServidor.setBounds(375, 93, 130, 22);
		panel.add(comboBoxTipoServidor);
		
		JLabel lblTelefoneServidor = new JLabel("Telefone");
		lblTelefoneServidor.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblTelefoneServidor.setBounds(434, 132, 71, 14);
		panel.add(lblTelefoneServidor);
		
		textFieldTelefoneServidor = new JTextField();
		textFieldTelefoneServidor.setBounds(434, 151, 102, 20);
		panel.add(textFieldTelefoneServidor);
		textFieldTelefoneServidor.setColumns(10);
		
		JPanel panel_1 = new JPanel();
		tabbedPane.addTab("Listagem", null, panel_1, null);
		
		JButton btnConsultar = new JButton("Consultar");
		btnConsultar.setBounds(212, 5, 89, 23);
		btnConsultar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Connection connection;
				try {
					connection = DBConnection.getInstance().getConnection();
					System.out.println(connection.getCatalog());
					String sql = "select * from servidor";
					PreparedStatement preparedStatement1 = connection.prepareStatement(sql);
								
					ResultSet rs = preparedStatement1.executeQuery();

					DefaultTableModel modelo = (DefaultTableModel) tbServidor.getModel();

					modelo.setNumRows(0);

					while (rs.next()) {
			
						modelo.addRow(new Object[]{rs.getString("id"), rs.getString("nome"), rs.getString("matricula"), rs.getString("email"), rs.getDate("data_cadastro")});

					}
		
					rs.close();
					connection.close();
			

				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}				
					

			}
			
	});
		panel_1.setLayout(null);
		panel_1.add(btnConsultar);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 48, 526, 273);
		panel_1.add(scrollPane);
		
		tbServidor = new JTable();
		tbServidor.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				
				int linha = tbServidor.getSelectedRow();
								
			
				txtIdServidor.setText(tbServidor.getValueAt(linha, 0).toString());
				textFieldNomeServidor.setText(tbServidor.getValueAt(linha, 1).toString());
				txtMatricula.setText(tbServidor.getValueAt(linha, 2).toString());
				textEmailServidor.setText(tbServidor.getValueAt(linha, 3).toString());
				txtDataServidor.setText(tbServidor.getValueAt(linha, 4).toString());
					
			}
		});
		tbServidor.setFont(new Font("Tahoma", Font.PLAIN, 10));
		tbServidor.setModel(new DefaultTableModel(
			new Object[][] {
				{null, null, null, null, null},
			},
			new String[] {
				"ID", "NOME DO SERVIDOR", "MATRICULA", "EMAIL", "DATA DE CADASTRO"
			}
		) {
			Class[] columnTypes = new Class[] {
				Integer.class, Object.class, Object.class, Object.class, Object.class
			};
			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
		});
		tbServidor.getColumnModel().getColumn(1).setPreferredWidth(155);
		tbServidor.getColumnModel().getColumn(2).setPreferredWidth(135);
		tbServidor.getColumnModel().getColumn(3).setPreferredWidth(162);
		tbServidor.getColumnModel().getColumn(4).setPreferredWidth(128);
		scrollPane.setViewportView(tbServidor);
		
		JButton btnAlterar = new JButton("Alterar");
		btnAlterar.setBounds(161, 377, 117, 29);
		btnAlterar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Connection connection;
				
				Servidor servidor = new Servidor();
				ServidorController ServidorController = new ServidorController();
				
				DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
				LocalDate data = LocalDate.parse(txtDataServidor.getText(), formatter);
				
				servidor.setId(Integer.valueOf(txtIdServidor.getText()));
				servidor.setNome(textFieldNomeServidor.getText());
				servidor.setMatricula(txtMatricula.getText());
				servidor.setEmail(textEmailServidor.getText());
				servidor.setData_cadastro(data);								
									
												
								
				boolean resultado = ServidorController.alterar(servidor);
				if (resultado == true) {
					JOptionPane.showMessageDialog(null,
							"Dados gravados!",
					        "Processo concluído",
					        JOptionPane.INFORMATION_MESSAGE);
				}else {
					JOptionPane.showMessageDialog(null,
							"Houve um erro ao gravar os dados no banco de dados!",
					        "Impossível continuar",
					        JOptionPane.ERROR_MESSAGE);
				}
			}
		});
		contentPane.add(btnAlterar);
		
		JButton btnExcluir = new JButton("Excluir");
		btnExcluir.setBounds(271, 377, 117, 29);
		btnExcluir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			
			Connection connection;
			
			Servidor servidor = new Servidor();
			ServidorController servidorController = new ServidorController();
			
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
			LocalDate data = LocalDate.parse(txtDataServidor.getText(), formatter);
			
			servidor.setId(Integer.valueOf(txtIdServidor.getText()));
			servidor.setNome(textFieldNomeServidor.getText());
			servidor.setEmail(textEmailServidor.getText());
			servidor.setMatricula(txtMatricula.getText());
			servidor.setData_cadastro(data);									
							
			boolean resultado = servidorController.excluir(servidor);
			if (resultado == true) {
				JOptionPane.showMessageDialog(null,
						"Excluido com sucesso!",
				        "Processo concluído",
				        JOptionPane.INFORMATION_MESSAGE);
			}else {
				JOptionPane.showMessageDialog(null,
						"Houve um erro ao gravar os dados no banco de dados!",
				        "Impossível continuar",
				        JOptionPane.ERROR_MESSAGE);
			}
		}
	});
		contentPane.add(btnExcluir);
	}
}