package view;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JFormattedTextField;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import controller.AlunoController;
import model.Aluno;
import model.Cidade;
import model.Curso;
import repositorio.CidadeRepositorio;
import repositorio.CursoRepositorio;
import repositorio.DBConnection;

import java.awt.Font;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JTable;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;

import org.postgresql.util.PSQLException;
import javax.swing.JComboBox;
import java.awt.Color;
import javax.swing.JScrollPane;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.SwingConstants;
import javax.swing.event.AncestorListener;
import javax.swing.event.AncestorEvent;

public class VAlunos extends JFrame {

	private JPanel contentPane;
	private JTextField txtId;
	private JTextField txtNumero_matricula;
	private JTextField txtNome;
	private JTextField txtEmail;
	private JFormattedTextField txtData;
	private JTextField textField;
	private JTable tbAluno;
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					VAlunos frame = new VAlunos();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public VAlunos() {
		setTitle("Cadastro de Aluno");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 583, 456);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		setLocationRelativeTo(contentPane);
		
		JButton btnSalvar = new JButton("Salvar");
		btnSalvar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Aluno aluno = new Aluno();
				AlunoController cieeController = new AlunoController();
				
				/**DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
				LocalDate data = LocalDate.parse(txtData.getText(), formatter);*/
				
				aluno.setId(Integer.valueOf(txtId.getText()));
				aluno.setNome(txtNome.getText());
				aluno.setNumero_matricula(Integer.valueOf(txtNumero_matricula.getText()));
				aluno.setEmail(txtEmail.getText());
				aluno.setData_cadastro(txtData.getText());								
				
				boolean resultado = cieeController.salvar(aluno);
				if (resultado == true) {
					JOptionPane.showMessageDialog(null,
							"Dados gravados!",
					        "Processo concluído",
					        JOptionPane.INFORMATION_MESSAGE);
				}else {
					JOptionPane.showMessageDialog(null,
							"Houve um erro ao gravar os dados no banco de dados!",
					        "Impossível continuar",
					        JOptionPane.ERROR_MESSAGE);
				}
			}
		});
		btnSalvar.setBounds(38, 364, 117, 29);
		contentPane.add(btnSalvar);
		
		JButton btnFechar = new JButton("Fechar");
		btnFechar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		btnFechar.setBounds(371, 364, 117, 29);
		contentPane.add(btnFechar);
		
		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane.setBounds(6, 6, 551, 360);
		contentPane.add(tabbedPane);
		
		JPanel panel = new JPanel();
		tabbedPane.addTab("Cadastro", null, panel, null);
		
		JLabel lblId = new JLabel("Id");
		lblId.setBounds(22, 21, 12, 16);
		lblId.setFont(new Font("Tahoma", Font.PLAIN, 12));
		
		txtId = new JTextField();
		txtId.setBounds(21, 43, 95, 26);
		txtId.setColumns(10);
		
		JLabel lblData = new JLabel("Data cadastro");
		lblData.setBounds(389, 21, 82, 16);
		lblData.setFont(new Font("Tahoma", Font.PLAIN, 12));
		
		txtData = new JFormattedTextField();
		txtData.setBounds(390, 43, 114, 26);
		txtData.setHorizontalAlignment(SwingConstants.CENTER);
		
		JLabel lblNome = new JLabel("Nome");
		lblNome.setBounds(22, 96, 37, 16);
		lblNome.setFont(new Font("Tahoma", Font.PLAIN, 13));
		
		txtNumero_matricula = new JTextField();
		txtNumero_matricula.setBounds(181, 44, 130, 26);
		txtNumero_matricula.setColumns(10);
		
		txtNome = new JTextField();
		txtNome.setBounds(22, 114, 286, 26);
		txtNome.setColumns(10);
		
		JLabel lblNumero_matricula = new JLabel("Numero Matricula");
		lblNumero_matricula.setBounds(186, 21, 95, 16);
		lblNumero_matricula.setFont(new Font("Tahoma", Font.PLAIN, 12));
		
		JLabel lblEmail = new JLabel("Email");
		lblEmail.setBounds(22, 151, 46, 14);
		lblEmail.setFont(new Font("Tahoma", Font.PLAIN, 13));
		
		txtEmail = new JTextField();
		txtEmail.setBounds(22, 167, 219, 24);
		txtEmail.setColumns(10);
		panel.setLayout(null);
		panel.add(lblNome);
		panel.add(txtNome);
		panel.add(lblEmail);
		panel.add(txtEmail);
		panel.add(txtId);
		panel.add(lblId);
		panel.add(lblNumero_matricula);
		panel.add(lblData);
		panel.add(txtNumero_matricula);
		panel.add(txtData);
		
		JLabel lblCidade = new JLabel("Cidade");
		lblCidade.setBounds(30, 213, 46, 14);
		panel.add(lblCidade);
		
		final JComboBox cbCidade = new JComboBox();
		cbCidade.addAncestorListener(new AncestorListener() {
			public void ancestorAdded(AncestorEvent event) {
								
				CidadeRepositorio cidade = new CidadeRepositorio();
				List<Cidade> lista = cidade.buscarTodos();
				
				cbCidade.removeAll();
				
				for(Cidade f:lista) {
					cbCidade.addItem(f);
				}
			}
			public void ancestorMoved(AncestorEvent event) {
			}
			public void ancestorRemoved(AncestorEvent event) {
			}
		});
		cbCidade.setBounds(27, 228, 135, 22);
		panel.add(cbCidade);
		
		JLabel lblUF = new JLabel("UF");
		lblUF.setBounds(202, 213, 46, 14);
		panel.add(lblUF);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setBounds(202, 228, 73, 23);
		panel.add(comboBox);
		
		JLabel lblTelefoneAluno = new JLabel("Telefone");
		lblTelefoneAluno.setBounds(320, 153, 75, 14);
		lblTelefoneAluno.setFont(new Font("Tahoma", Font.PLAIN, 11));
		panel.add(lblTelefoneAluno);
		
		textField = new JTextField();
		textField.setBounds(320, 171, 196, 23);
		panel.add(textField);
		textField.setColumns(10);
		
		JLabel lblCursoAluno = new JLabel("Curso");
		lblCursoAluno.setBounds(332, 99, 46, 14);
		panel.add(lblCursoAluno);
		
		final JComboBox cbCurso = new JComboBox();
		cbCurso.addAncestorListener(new AncestorListener() {
			public void ancestorAdded(AncestorEvent event) {
				
				CursoRepositorio curso = new CursoRepositorio();
				List<Curso> lista = curso.buscarTodos();
				
				cbCurso.removeAll();
				
				for(Curso f:lista) {
					cbCurso.addItem(f);
				}
			}
			public void ancestorMoved(AncestorEvent event) {
			}
			public void ancestorRemoved(AncestorEvent event) {
			}
		});
		cbCurso.setBounds(334, 115, 183, 26);
		panel.add(cbCurso);
		
		Component horizontalStrut = Box.createHorizontalStrut(20);
		horizontalStrut.setBounds(10, 309, 530, 12);
		panel.add(horizontalStrut);
		
		JPanel panel_1 = new JPanel();
		tabbedPane.addTab("Listagem", null, panel_1, null);
		
		JButton btnConsultar = new JButton("Consultar");
		btnConsultar.setBounds(212, 5, 89, 23);
		btnConsultar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Connection connection;
				try {
					connection = DBConnection.getInstance().getConnection();
					System.out.println(connection.getCatalog());
					String sql = "select * from aluno";
					PreparedStatement preparedStatement1 = connection.prepareStatement(sql);
								
					ResultSet rs = preparedStatement1.executeQuery();

					DefaultTableModel modelo = (DefaultTableModel) tbAluno.getModel();

					modelo.setNumRows(0);

					while (rs.next()) {
			
						modelo.addRow(new Object[]{rs.getString("id"), rs.getString("nome"), rs.getString("numero_matricula"),rs.getString("email"),rs.getString("data_cadastro")});

					}
		
					rs.close();
					connection.close();
			

				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}				
					

			}
			
	});
		panel_1.setLayout(null);
		panel_1.add(btnConsultar);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 48, 526, 273);
		panel_1.add(scrollPane);
		
		tbAluno = new JTable();
		tbAluno.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				
				int linha = tbAluno.getSelectedRow();
				
				
				/*DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
				LocalDate data = LocalDate.parse(txtData.getText(), formatter);*/
				
				txtId.setText(tbAluno.getValueAt(linha, 0).toString());
				txtNome.setText(tbAluno.getValueAt(linha, 1).toString());
				txtNumero_matricula.setText(tbAluno.getValueAt(linha, 2).toString());
				txtEmail.setText(tbAluno.getValueAt(linha, 3).toString());
				txtData.setText(tbAluno.getValueAt(linha, 4).toString());
					
			}
		});
		tbAluno.setFont(new Font("Tahoma", Font.PLAIN, 10));
		tbAluno.setModel(new DefaultTableModel(
			new Object[][] {
				{null, null, null, null, null},
			},
			new String[] {
				"ID", "NOME", "MATRICULA", "EMAIL", "DATA DE CADASTRO"
			}
		) {
			Class[] columnTypes = new Class[] {
				Integer.class, Object.class, Object.class, Object.class, Object.class
			};
			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
			boolean[] columnEditables = new boolean[] {
				false, true, true, true, true
			};
			public boolean isCellEditable(int row, int column) {
				return columnEditables[column];
			}
		});
		tbAluno.getColumnModel().getColumn(1).setPreferredWidth(155);
		tbAluno.getColumnModel().getColumn(2).setPreferredWidth(135);
		tbAluno.getColumnModel().getColumn(3).setPreferredWidth(162);
		tbAluno.getColumnModel().getColumn(4).setPreferredWidth(128);
		scrollPane.setViewportView(tbAluno);
		
		JButton btnAlterar = new JButton("Alterar");
		btnAlterar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Connection connection;
				
				Aluno aluno = new Aluno();
				AlunoController alunoController = new AlunoController();
				
							
				aluno.setId(Integer.valueOf(txtId.getText()));
				aluno.setNome(txtNome.getText());
				aluno.setNumero_matricula(Integer.valueOf(txtNumero_matricula.getText()));
				aluno.setEmail(txtEmail.getText());
				aluno.setData_cadastro(txtData.getText());								
								
				boolean resultado = alunoController.alterar(aluno);
				if (resultado == true) {
					JOptionPane.showMessageDialog(null,
							"Dados gravados!",
					        "Processo concluído",
					        JOptionPane.INFORMATION_MESSAGE);
				}else {
					JOptionPane.showMessageDialog(null,
							"Houve um erro ao gravar os dados no banco de dados!",
					        "Impossível continuar",
					        JOptionPane.ERROR_MESSAGE);
				}
			}
		});

		btnAlterar.setBounds(151, 364, 117, 29);
		contentPane.add(btnAlterar);
		
		JButton btnExcluir = new JButton("Excluir");
		btnExcluir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			
			Connection connection;
			
			Aluno aluno = new Aluno();
			AlunoController alunoController = new AlunoController();
			
				
			aluno.setId(Integer.valueOf(txtId.getText()));
			aluno.setNome(txtNome.getText());
			aluno.setNumero_matricula(Integer.valueOf(txtNumero_matricula.getText()));
			aluno.setEmail(txtEmail.getText());
			aluno.setData_cadastro(txtData.getText());									
							
			boolean resultado = alunoController.excluir(aluno);
			if (resultado == true) {
				JOptionPane.showMessageDialog(null,
						"Excluido com sucesso!",
				        "Processo concluído",
				        JOptionPane.INFORMATION_MESSAGE);
			}else {
				JOptionPane.showMessageDialog(null,
						"Houve um erro ao gravar os dados no banco de dados!",
				        "Impossível continuar",
				        JOptionPane.ERROR_MESSAGE);
			}
		}
	});
		btnExcluir.setBounds(261, 364, 117, 29);
		contentPane.add(btnExcluir);
	}
}