package model;

import java.sql.Date;
import java.time.LocalDate;
import java.util.Collection;

public class Concedente extends ModeloAbstrato{

    private int id;
    private int numero_convenio;
    private String razao_social;
    private String nome_fantasia;
    private String responsavel_estagio;
    private String supervisor_estagio;
    private String inicio_convenio;
    private String fim_convenio;
    private String data_cadastro;
    private Cidade cidade;
    private Estagio estagio;
    private Collection<ConcedenteEmail> concedenteEmail;
    private Collection<ConcedenteTelefone> concedenteTelefone;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getNumero_convenio() {
		return numero_convenio;
	}
	public void setNumero_convenio(int numero_convenio) {
		this.numero_convenio = numero_convenio;
	}
	public String getRazao_social() {
		return razao_social;
	}
	public void setRazao_social(String razao_social) {
		this.razao_social = razao_social;
	}
	public String getNome_fantasia() {
		return nome_fantasia;
	}
	public void setNome_fantasia(String nome_fantasia) {
		this.nome_fantasia = nome_fantasia;
	}
	public String getResponsavel_estagio() {
		return responsavel_estagio;
	}
	public void setResponsavel_estagio(String responsavel_estagio) {
		this.responsavel_estagio = responsavel_estagio;
	}
	public String getSupervisor_estagio() {
		return supervisor_estagio;
	}
	public void setSupervisor_estagio(String supervisor_estagio) {
		this.supervisor_estagio = supervisor_estagio;
	}
	public String getInicio_convenio() {
		return inicio_convenio;
	}
	public void setInicio_convenio(String inicio_convenio) {
		this.inicio_convenio = inicio_convenio;
	}
	public String getFim_convenio() {
		return fim_convenio;
	}
	public void setFim_convenio(String fim_convenio) {
		this.fim_convenio = fim_convenio;
	}
	public String getData_cadastro() {
		return data_cadastro;
	}
	public void setData_cadastro(String data_cadastro) {
		this.data_cadastro = data_cadastro;
	}
	public Cidade getCidade() {
		return cidade;
	}
	public void setCidade(Cidade cidade) {
		this.cidade = cidade;
	}
	public Estagio getEstagio() {
		return estagio;
	}
	public void setEstagio(Estagio estagio) {
		this.estagio = estagio;
	}
	public Collection<ConcedenteEmail> getConcedenteEmail() {
		return concedenteEmail;
	}
	public void setConcedenteEmail(Collection<ConcedenteEmail> concedenteEmail) {
		this.concedenteEmail = concedenteEmail;
	}
	public Collection<ConcedenteTelefone> getConcedenteTelefone() {
		return concedenteTelefone;
	}
	public void setConcedenteTelefone(Collection<ConcedenteTelefone> concedenteTelefone) {
		this.concedenteTelefone = concedenteTelefone;
	}

	

}
