package model;

import java.util.Collection;
import java.util.List;

public class UF {

    private int id;

    private String uf;

    private Collection<Cidade> cidade;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUf() {
        return uf;
    }

    public void setUf(String uf) {
        this.uf = uf;
    }

    public Collection<Cidade> getCidade() {
        return cidade;
    }

    public void setCidade(Collection<Cidade> cidade) {
        this.cidade = cidade;
    }
    
    
	public List<UF> listaruf() {
		// TODO Auto-generated method stub
		return null;
	}
		@Override
		public String toString() {
		return this.getUf();
	}

}
