package model;

import java.sql.Date;
import java.time.LocalDate;

public class EncerramentoEstagio {

    private int id;
    private String data_encerramento;
    private String data_entrega_docs;
    private String data_aprovacao;
    private int status;
    private String observacao;
    private String data_cadastro;
    private Estagio estagio;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getData_encerramento() {
		return data_encerramento;
	}
	public void setData_encerramento(String data_encerramento) {
		this.data_encerramento = data_encerramento;
	}
	public String getData_entrega_docs() {
		return data_entrega_docs;
	}
	public void setData_entrega_docs(String data_entrega_docs) {
		this.data_entrega_docs = data_entrega_docs;
	}
	public String getData_aprovacao() {
		return data_aprovacao;
	}
	public void setData_aprovacao(String data_aprovacao) {
		this.data_aprovacao = data_aprovacao;
	}
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	public String getObservacao() {
		return observacao;
	}
	public void setObservacao(String observacao) {
		this.observacao = observacao;
	}
	public String getData_cadastro() {
		return data_cadastro;
	}
	public void setData_cadastro(String data_cadastro) {
		this.data_cadastro = data_cadastro;
	}
	public Estagio getEstagio() {
		return estagio;
	}
	public void setEstagio(Estagio estagio) {
		this.estagio = estagio;
	}

  
}
