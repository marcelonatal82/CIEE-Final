package model;

import java.sql.Date;
import java.time.LocalDate;

public class ModeloAbstratoEstagio {

    private int id;
    private int modalidade_estagio;
    private String data_inicio;
    private String data_fim;
    private int data_previsao_entrega;
    private String data_cadastro;
    private AgenteMediador agenteMediador;
    private RegistroEstagio registroEstagio;
    private Aluno aluno;
    private Concedente concedente;
    private EncerramentoEstagio encerramentoEstagio;
    private Servidor servidor;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getModalidade_estagio() {
		return modalidade_estagio;
	}
	public void setModalidade_estagio(int modalidade_estagio) {
		this.modalidade_estagio = modalidade_estagio;
	}
	public String getData_inicio() {
		return data_inicio;
	}
	public void setData_inicio(String data_inicio) {
		this.data_inicio = data_inicio;
	}
	public String getData_fim() {
		return data_fim;
	}
	public void setData_fim(String data_fim) {
		this.data_fim = data_fim;
	}
	public int getData_previsao_entrega() {
		return data_previsao_entrega;
	}
	public void setData_previsao_entrega(int data_previsao_entrega) {
		this.data_previsao_entrega = data_previsao_entrega;
	}
	public String getData_cadastro() {
		return data_cadastro;
	}
	public void setData_cadastro(String data_cadastro) {
		this.data_cadastro = data_cadastro;
	}
	public AgenteMediador getAgenteMediador() {
		return agenteMediador;
	}
	public void setAgenteMediador(AgenteMediador agenteMediador) {
		this.agenteMediador = agenteMediador;
	}
	public RegistroEstagio getRegistroEstagio() {
		return registroEstagio;
	}
	public void setRegistroEstagio(RegistroEstagio registroEstagio) {
		this.registroEstagio = registroEstagio;
	}
	public Aluno getAluno() {
		return aluno;
	}
	public void setAluno(Aluno aluno) {
		this.aluno = aluno;
	}
	public Concedente getConcedente() {
		return concedente;
	}
	public void setConcedente(Concedente concedente) {
		this.concedente = concedente;
	}
	public EncerramentoEstagio getEncerramentoEstagio() {
		return encerramentoEstagio;
	}
	public void setEncerramentoEstagio(EncerramentoEstagio encerramentoEstagio) {
		this.encerramentoEstagio = encerramentoEstagio;
	}
	public Servidor getServidor() {
		return servidor;
	}
	public void setServidor(Servidor servidor) {
		this.servidor = servidor;
	}
    
    
	

}
