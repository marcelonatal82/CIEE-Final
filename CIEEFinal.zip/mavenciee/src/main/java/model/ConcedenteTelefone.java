package model;

public class ConcedenteTelefone {

    private int id;
    private String telefone;
    private Concedente concedente;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getTelefone() {
		return telefone;
	}
	public void setTelefone(String telefone) {
		this.telefone = telefone;
	}
	public Concedente getConcedente() {
		return concedente;
	}
	public void setConcedente(Concedente concedente) {
		this.concedente = concedente;
	}
    
    
}
