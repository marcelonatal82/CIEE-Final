package model;

import java.sql.Date;
import java.time.LocalDate;
import java.util.Collection;

public class ModeloAbstratoUf {
    public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getUf() {
		return uf;
	}

	public void setUf(String uf) {
		this.uf = uf;
	}

	public Collection<Cidade> getCidade() {
		return cidade;
	}

	public void setCidade(Collection<Cidade> cidade) {
		this.cidade = cidade;
	}

	private int id;

    private String uf;

    private Collection<Cidade> cidade;
}
