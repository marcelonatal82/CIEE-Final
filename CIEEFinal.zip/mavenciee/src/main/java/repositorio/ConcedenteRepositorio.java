package repositorio;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import model.Concedente;

public class ConcedenteRepositorio implements Serializable{

	Logger logger = Logger.getLogger(ConcedenteRepositorio.class);
	
	public boolean salvar(Concedente modelo) {
		logger.info("--- Início do método Salvar ---");

		try {
			Connection connection = DBConnection.getInstance().getConnection();

			String insert = "INSERT INTO concedente (id, numero_convenio, razao_social, nome_fantasia, responsavel_estagio, supervisor_estagio, inicio_convenio, fim_convenio, data_cadastro) values (?, ?, ?, ?, ?, ?, ?, ?, ?)";
			PreparedStatement preparedStatement1 = connection.prepareStatement(insert);
			preparedStatement1.setInt(1, modelo.getId());
			preparedStatement1.setInt(2, modelo.getNumero_convenio());
			preparedStatement1.setString(3, modelo.getRazao_social());
			preparedStatement1.setString(4, modelo.getNome_fantasia());
			preparedStatement1.setString(5, modelo.getResponsavel_estagio());
			preparedStatement1.setString(6, modelo.getSupervisor_estagio());
			preparedStatement1.setString(7, modelo.getInicio_convenio());
			preparedStatement1.setString(8, modelo.getFim_convenio());
			preparedStatement1.setString(9, modelo.getData_cadastro());
			
			int resultado = preparedStatement1.executeUpdate();

			if (resultado > 0) {
				logger.info("Retorno maior que zero da execução do insert na tabela de concedente: " + resultado);
				logger.info("--- Fim do método Salvar ---");
				return true;
			} else {
				logger.info("Retorno menor que zero da execução do insert na tabela de concedente: " + resultado);
				logger.info("--- Fim do método Salvar ---");
				return false;

			}
		} catch (Exception e) {
			logger.error("Ocorreu um erro ao tentar salvar: " + e.getMessage());
			logger.error("--- Fim do método Salvar ---");
			return false;
		}
	}

	public boolean alterar(Concedente modelo) {
		logger.info("--- Início do método Alterar ---");

		try {
			Connection connection = DBConnection.getInstance().getConnection();

			String insert = "update concedente set numero_convenio = ?, razao_social = ?, nome_fantasia = ?, responsavel_estagio = ?, supervisor_estagio = ?, inicio_convenio = ?, fim_convenio = ?,  data_cadastro = ? where id = ?";
			PreparedStatement preparedStatement1 = connection.prepareStatement(insert);
			preparedStatement1.setInt(1, modelo.getId());
			preparedStatement1.setInt(2, modelo.getNumero_convenio());
			preparedStatement1.setString(3, modelo.getRazao_social());
			preparedStatement1.setString(4, modelo.getNome_fantasia());
			preparedStatement1.setString(5, modelo.getResponsavel_estagio());
			preparedStatement1.setString(6, modelo.getSupervisor_estagio());
			preparedStatement1.setString(7, modelo.getInicio_convenio());
			preparedStatement1.setString(8, modelo.getFim_convenio());
			preparedStatement1.setString(9, modelo.getData_cadastro());
			int resultado = preparedStatement1.executeUpdate();

			if (resultado > 0) {
				logger.info("Retorno maior que zero da execução do update na tabela de Concedente: " + resultado);
				logger.info("--- Fim do método Alterar ---");
				return true;
			} else {
				logger.info("Retorno menor que zero da execução de update na tabela de Concedente: " + resultado);
				logger.info("--- Fim do método Alterar ---");
				return false;

			}
		} catch (Exception e) {
			logger.error("Ocorreu um erro ao tentar alterar: " + e.getMessage());
			logger.error("--- Fim do método Alterar ---");
			return false;
		}
	}

	public boolean excluir(Concedente modelo) {
		logger.info("--- Início do método Excluir ---");

		try {
			Connection connection = DBConnection.getInstance().getConnection();

			String insert = "delete from Concedente where id = ?";
			PreparedStatement preparedStatement1 = connection.prepareStatement(insert);
			preparedStatement1.setInt(1, modelo.getId());
			logger.info("String delete do Concedente preparada: " + preparedStatement1);
			int resultado = preparedStatement1.executeUpdate();

			if (resultado > 0) {
				logger.info("Retorno maior que zero do delete na tabela de Concedente: " + resultado);
				logger.info("--- Fim do método Excluir ---");
				return true;
			} else {
				logger.info("Retorno menor que zero do delete na tabela de Concedente: " + resultado);
				logger.info("--- Fim do método Excluir ---");
				return false;

			}
		} catch (Exception e) {
			logger.error("Ocorreu um erro ao tentar excluir: " + e.getMessage());
			logger.error("--- Fim do método Excluir ---");
			return false;
		}
	}

	public boolean buscar(Concedente modelo) {
		// TODO Auto-generated method stub
		return false;
	}

	public Concedente buscar(int id) {
		logger.info("--- Início do método Buscar por Id ---");

		try {
			Connection connection = DBConnection.getInstance().getConnection();
	
			String consulta = "select * from concedente "
							+ "where id = ?";
			Concedente Concedente = new Concedente();
	
			PreparedStatement preparedStatement = connection.prepareStatement(consulta);
			preparedStatement.setInt(1, id);
			ResultSet resultSet = preparedStatement.executeQuery();
			logger.info("Consulta executada: " + preparedStatement);
	
			while (resultSet.next()) {
				Concedente.setId(resultSet.getInt("id"));
				Concedente.setNumero_convenio(resultSet.getInt("numero_convenio"));
				Concedente.setRazao_social(resultSet.getString("razao_social"));
				Concedente.setNome_fantasia(resultSet.getString("nome_fantasia"));
				Concedente.setResponsavel_estagio(resultSet.getString("responsavel_estagio"));
				Concedente.setSupervisor_estagio(resultSet.getString("supervisor_estagio"));
				Concedente.setInicio_convenio(resultSet.getString("inicio_convenio"));
				Concedente.setFim_convenio(resultSet.getString("fim_convenio"));							
				Concedente.setData_cadastro(resultSet.getString("data_cadastro"));	
								
			}
	
			logger.info("--- Fim do método Buscar por Id ---");
	
			return Concedente;
		} catch (Exception e) {
			logger.error("Ocorreu um erro ao tentar buscar um Concedente: " + e.getMessage());
			logger.error("--- Fim do método Buscar por Id ---");
			return null;
		}
	}

	public List<Concedente> buscarTodos() {
		logger.info("--- Início do método Buscar Todos ---");

		try {
			Connection connection = DBConnection.getInstance().getConnection();
	
			String consulta = "select * from Concedente";
			List<Concedente> lista = new ArrayList<Concedente>();
			Concedente Concedente;
	
			PreparedStatement preparedStatement = connection.prepareStatement(consulta);
			ResultSet resultSet = preparedStatement.executeQuery();
			logger.info("Consulta executada: " + preparedStatement);
	
			while (resultSet.next()) {
				Concedente = new Concedente();
				Concedente.setId(resultSet.getInt("id"));
				Concedente.setNumero_convenio(resultSet.getInt("numero_convenio"));
				Concedente.setRazao_social(resultSet.getString("razao_social"));
				Concedente.setNome_fantasia(resultSet.getString("nome_fantasia"));
				Concedente.setResponsavel_estagio(resultSet.getString("responsavel_estagio"));
				Concedente.setSupervisor_estagio(resultSet.getString("supervisor_estagio"));
				Concedente.setInicio_convenio(resultSet.getString("inicio_convenio"));
				Concedente.setFim_convenio(resultSet.getString("fim_convenio"));							
				Concedente.setData_cadastro(resultSet.getString("data_cadastro"));
				lista.add(Concedente);
			}
			
			logger.info("Quantidade de registros pesquisados: " + lista.size());
			logger.info("--- Fim do método Buscar Todos ---");

			return lista;
		} catch (Exception e) {
			logger.error("Ocorreu um erro ao tentar executar o método buscar todos do Concedente: " + e.getMessage());
			logger.error("--- Fim do método Buscar Todos ---");
			return null;
		}

	}
}
