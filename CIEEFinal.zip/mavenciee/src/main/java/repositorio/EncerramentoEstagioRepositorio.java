package repositorio;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import model.EncerramentoEstagio;

public class EncerramentoEstagioRepositorio implements Serializable{

	Logger logger = Logger.getLogger(EncerramentoEstagioRepositorio.class);
	
	public boolean salvar(EncerramentoEstagio modelo) {
		logger.info("--- Início do método Salvar ---");

		try {
			Connection connection = DBConnection.getInstance().getConnection();

			String insert = "INSERT INTO EncerramentoEstagio (id, data_encerramento1, data_entrega_docs1, data_aprovacao1, status, observacao, data_cadastro1) values (?, ?, ?, ?, ?, ?, ?)";
			PreparedStatement preparedStatement1 = connection.prepareStatement(insert);
			preparedStatement1.setInt(1,  modelo.getId());
			preparedStatement1.setString(2, modelo.getData_encerramento());
			preparedStatement1.setString(3, modelo.getData_entrega_docs());
			preparedStatement1.setString(4, modelo.getData_aprovacao());
			preparedStatement1.setInt(5,  modelo.getStatus());
			preparedStatement1.setString(6, modelo.getData_cadastro());
			
			int resultado = preparedStatement1.executeUpdate();

			if (resultado > 0) {
				logger.info("Retorno maior que zero da execução do insert na tabela de EncerramentoEstagio: " + resultado);
				logger.info("--- Fim do método Salvar ---");
				return true;
			} else {
				logger.info("Retorno menor que zero da execução do insert na tabela de EncerramentoEstagio: " + resultado);
				logger.info("--- Fim do método Salvar ---");
				return false;

			}
		} catch (Exception e) {
			logger.error("Ocorreu um erro ao tentar salvar: " + e.getMessage());
			logger.error("--- Fim do método Salvar ---");
			return false;
		}
	}

	public boolean alterar(EncerramentoEstagio modelo) {
		logger.info("--- Início do método Alterar ---");

		try {
			Connection connection = DBConnection.getInstance().getConnection();

			String insert = "update EncerramentoEstagio data_encerramento1 = ?, data_entrega_docs1 = ?, data_aprovacao1 = ?, status = ?, observacao = ?, data_cadastro1 = ? where id = ?";
			PreparedStatement preparedStatement1 = connection.prepareStatement(insert);
			preparedStatement1.setInt(1,  modelo.getId());
			preparedStatement1.setString(2, modelo.getData_encerramento());
			preparedStatement1.setString(3, modelo.getData_entrega_docs());
			preparedStatement1.setString(4, modelo.getData_aprovacao());
			preparedStatement1.setInt(5,  modelo.getStatus());
			preparedStatement1.setString(6, modelo.getData_cadastro());
			int resultado = preparedStatement1.executeUpdate();

			if (resultado > 0) {
				logger.info("Retorno maior que zero da execução do update na tabela de EncerramentoEstagio: " + resultado);
				logger.info("--- Fim do método Alterar ---");
				return true;
			} else {
				logger.info("Retorno menor que zero da execução de update na tabela de EncerramentoEstagio: " + resultado);
				logger.info("--- Fim do método Alterar ---");
				return false;

			}
		} catch (Exception e) {
			logger.error("Ocorreu um erro ao tentar alterar: " + e.getMessage());
			logger.error("--- Fim do método Alterar ---");
			return false;
		}
	}

	public boolean excluir(EncerramentoEstagio modelo) {
		logger.info("--- Início do método Excluir ---");

		try {
			Connection connection = DBConnection.getInstance().getConnection();

			String insert = "delete from EncerramentoEstagio where id = ?";
			PreparedStatement preparedStatement1 = connection.prepareStatement(insert);
			preparedStatement1.setInt(1, modelo.getId());
			logger.info("String delete do aluno preparada: " + preparedStatement1);
			int resultado = preparedStatement1.executeUpdate();

			if (resultado > 0) {
				logger.info("Retorno maior que zero do delete na tabela de EncerramentoEstagio: " + resultado);
				logger.info("--- Fim do método Excluir ---");
				return true;
			} else {
				logger.info("Retorno menor que zero do delete na tabela de EncerramentoEstagio: " + resultado);
				logger.info("--- Fim do método Excluir ---");
				return false;

			}
		} catch (Exception e) {
			logger.error("Ocorreu um erro ao tentar excluir: " + e.getMessage());
			logger.error("--- Fim do método Excluir ---");
			return false;
		}
	}


	public EncerramentoEstagio buscar(int id) {
		logger.info("--- Início do método Buscar por Id ---");

		try {
			Connection connection = DBConnection.getInstance().getConnection();
	
			String consulta = "select * from EncerramentoEstagio "
							+ "where id = ?";
			EncerramentoEstagio encerramentoestagio = new EncerramentoEstagio();
	
			PreparedStatement preparedStatement = connection.prepareStatement(consulta);
			preparedStatement.setInt(1, id);
			ResultSet resultSet = preparedStatement.executeQuery();
			logger.info("Consulta executada: " + preparedStatement);
	
			while (resultSet.next()) {
				encerramentoestagio.setId(resultSet.getInt("id"));
				encerramentoestagio.setData_encerramento(resultSet.getString("data_encerramento1"));
				encerramentoestagio.setData_entrega_docs(resultSet.getString("Data_entrega_docs1"));
				encerramentoestagio.setData_aprovacao(resultSet.getString("Data_aprovacao1"));
				encerramentoestagio.setStatus(resultSet.getInt("status"));
				encerramentoestagio.setData_cadastro(resultSet.getString("Data_cadastro1"));
						
								
			}
	
			logger.info("--- Fim do método Buscar por Id ---");
	
			return encerramentoestagio;
		} catch (Exception e) {
			logger.error("Ocorreu um erro ao tentar buscar um EncerramentoEstagio: " + e.getMessage());
			logger.error("--- Fim do método Buscar por Id ---");
			return null;
		}
	}

	public List<EncerramentoEstagio> buscarTodos() {
		logger.info("--- Início do método Buscar Todos ---");

		try {
			Connection connection = DBConnection.getInstance().getConnection();
	
			String consulta = "select * from encerramentoEstagio";
			List<EncerramentoEstagio> lista = new ArrayList<EncerramentoEstagio>();
			EncerramentoEstagio encerramentoEstagio;
	
			PreparedStatement preparedStatement = connection.prepareStatement(consulta);
			ResultSet resultSet = preparedStatement.executeQuery();
			logger.info("Consulta executada: " + preparedStatement);
	
			while (resultSet.next()) {
				encerramentoEstagio = new EncerramentoEstagio();
				
				encerramentoEstagio.setId(resultSet.getInt("id"));
				encerramentoEstagio.setData_encerramento(resultSet.getString("data_encerramento1"));
				encerramentoEstagio.setData_entrega_docs(resultSet.getString("data_entrega_docs1"));
				encerramentoEstagio.setData_aprovacao(resultSet.getString("data_aprovacao1"));
				encerramentoEstagio.setStatus(resultSet.getInt("status"));
				encerramentoEstagio.setData_cadastro(resultSet.getString("data_cadastro1"));
				
				

					
				lista.add(encerramentoEstagio);
			}
			
			logger.info("Quantidade de registros pesquisados: " + lista.size());
			logger.info("--- Fim do método Buscar Todos ---");

			return lista;
		} catch (Exception e) {
			logger.error("Ocorreu um erro ao tentar executar o método buscar todos do EncerramentoEstagio: " + e.getMessage());
			logger.error("--- Fim do método Buscar Todos ---");
			return null;
		}

	}
}
