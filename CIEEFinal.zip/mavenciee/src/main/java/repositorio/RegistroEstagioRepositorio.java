package repositorio;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import model.RegistroEstagio;

public class RegistroEstagioRepositorio implements Serializable{

	Logger logger = Logger.getLogger(RegistroEstagioRepositorio.class);
	
	public boolean salvar(RegistroEstagio modelo) {
		logger.info("--- Início do método Salvar ---");

		try {
			Connection connection = DBConnection.getInstance().getConnection();

			String insert = "INSERT INTO RegistroEstagio (id, numero_registro, ano, data_registro, observacao, data_cadastro) values (?, ?, ?, ?, ?, ?)";
			PreparedStatement preparedStatement1 = connection.prepareStatement(insert);
			preparedStatement1.setInt(1, modelo.getId());
			preparedStatement1.setInt(2, modelo.getNumero_registro());
			preparedStatement1.setInt(3, modelo.getAno());
			preparedStatement1.setInt(4, modelo.getData_registro());
			preparedStatement1.setString(5, modelo.getObservacao());
			preparedStatement1.setString(5, modelo.getData_cadastro());

			int resultado = preparedStatement1.executeUpdate();

			if (resultado > 0) {
				logger.info("Retorno maior que zero da execução do insert na tabela de RegistroEstagio: " + resultado);
				logger.info("--- Fim do método Salvar ---");
				return true;
			} else {
				logger.info("Retorno menor que zero da execução do insert na tabela de RegistroEstagio: " + resultado);
				logger.info("--- Fim do método Salvar ---");
				return false;

			}
		} catch (Exception e) {
			logger.error("Ocorreu um erro ao tentar salvar: " + e.getMessage());
			logger.error("--- Fim do método Salvar ---");
			return false;
		}
	}

	public boolean alterar(RegistroEstagio modelo) {
		logger.info("--- Início do método Alterar ---");

		try {
			Connection connection = DBConnection.getInstance().getConnection();

			String insert = "update registroestagio set numero_registro = ?, ano = ?, data_registro = ?, observacao = ?, data_cadastro = ? where id = ?";
			PreparedStatement preparedStatement1 = connection.prepareStatement(insert);
			preparedStatement1.setInt(1, modelo.getId());
			preparedStatement1.setInt(2, modelo.getNumero_registro());
			preparedStatement1.setInt(3, modelo.getAno());
			preparedStatement1.setInt(4, modelo.getData_registro());
			preparedStatement1.setString(5, modelo.getObservacao());
			preparedStatement1.setString(5, modelo.getData_cadastro());
			int resultado = preparedStatement1.executeUpdate();

			if (resultado > 0) {
				logger.info("Retorno maior que zero da execução do update na tabela de RegistroEstagio: " + resultado);
				logger.info("--- Fim do método Alterar ---");
				return true;
			} else {
				logger.info("Retorno menor que zero da execução de update na tabela de RegistroEstagio: " + resultado);
				logger.info("--- Fim do método Alterar ---");
				return false;

			}
		} catch (Exception e) {
			logger.error("Ocorreu um erro ao tentar alterar: " + e.getMessage());
			logger.error("--- Fim do método Alterar ---");
			return false;
		}
	}

	public boolean excluir(RegistroEstagio modelo) {
		logger.info("--- Início do método Excluir ---");

		try {
			Connection connection = DBConnection.getInstance().getConnection();

			String insert = "delete from RegistroEstagio where id = ?";
			PreparedStatement preparedStatement1 = connection.prepareStatement(insert);
			preparedStatement1.setInt(1, modelo.getId());
			logger.info("String delete do RegistroEstagio preparada: " + preparedStatement1);
			int resultado = preparedStatement1.executeUpdate();

			if (resultado > 0) {
				logger.info("Retorno maior que zero do delete na tabela de RegistroEstagio: " + resultado);
				logger.info("--- Fim do método Excluir ---");
				return true;
			} else {
				logger.info("Retorno menor que zero do delete na tabela de RegistroEstagio: " + resultado);
				logger.info("--- Fim do método Excluir ---");
				return false;

			}
		} catch (Exception e) {
			logger.error("Ocorreu um erro ao tentar excluir: " + e.getMessage());
			logger.error("--- Fim do método Excluir ---");
			return false;
		}
	}

	public boolean buscar(RegistroEstagio modelo) {
		// TODO Auto-generated method stub
		return false;
	}

	public RegistroEstagio buscar(int id) {
		logger.info("--- Início do método Buscar por Id ---");

		try {
			Connection connection = DBConnection.getInstance().getConnection();
	
			String consulta = "select * from RegistroEstagio "
							+ "where id = ?";
			RegistroEstagio registroEstagio = new RegistroEstagio();
	
			PreparedStatement preparedStatement = connection.prepareStatement(consulta);
			preparedStatement.setInt(1, id);
			ResultSet resultSet = preparedStatement.executeQuery();
			logger.info("Consulta executada: " + preparedStatement);
	
			while (resultSet.next()) {
				registroEstagio.setId(resultSet.getInt("id"));
				registroEstagio.setNumero_registro(resultSet.getInt("numero_registro"));
				registroEstagio.setAno(resultSet.getInt("ano"));
				registroEstagio.setData_registro(resultSet.getInt("data_registro"));
				registroEstagio.setObservacao(resultSet.getString("observacao"));					
				registroEstagio.setData_cadastro(resultSet.getString("data_cadastro"));	
				
								
								
			}
	
			logger.info("--- Fim do método Buscar por Id ---");
	
			return registroEstagio;
		} catch (Exception e) {
			logger.error("Ocorreu um erro ao tentar buscar um RegistroEstagio: " + e.getMessage());
			logger.error("--- Fim do método Buscar por Id ---");
			return null;
		}
	}

	public List<RegistroEstagio> buscarTodos() {
		logger.info("--- Início do método Buscar Todos ---");

		try {
			Connection connection = DBConnection.getInstance().getConnection();
	
			String consulta = "select * from RegistroEstagio";
			List<RegistroEstagio> lista = new ArrayList<RegistroEstagio>();
			RegistroEstagio registroEstagio;
	
			PreparedStatement preparedStatement = connection.prepareStatement(consulta);
			ResultSet resultSet = preparedStatement.executeQuery();
			logger.info("Consulta executada: " + preparedStatement);
	
			while (resultSet.next()) {
				registroEstagio = new RegistroEstagio();
				registroEstagio.setId(resultSet.getInt("id"));
				registroEstagio.setNumero_registro(resultSet.getInt("numero_registro"));
				registroEstagio.setAno(resultSet.getInt("ano"));
				registroEstagio.setData_registro(resultSet.getInt("data_registro"));
				registroEstagio.setObservacao(resultSet.getString("observacao"));					
				registroEstagio.setData_cadastro(resultSet.getString("data_cadastro"));	
				lista.add(registroEstagio);
			}
			
			logger.info("Quantidade de registros pesquisados: " + lista.size());
			logger.info("--- Fim do método Buscar Todos ---");

			return lista;
		} catch (Exception e) {
			logger.error("Ocorreu um erro ao tentar executar o método buscar todos do RegistroEstagio: " + e.getMessage());
			logger.error("--- Fim do método Buscar Todos ---");
			return null;
		}

	}
}
